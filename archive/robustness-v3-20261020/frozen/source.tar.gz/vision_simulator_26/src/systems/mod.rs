mod camera;
mod chassis_observation;
mod controller;
mod debug;
mod fps;
mod gimbal_pid;
mod help;
mod input;
mod notice;
mod performance;
mod projectile;
mod uav;
pub use camera::*;
pub use chassis_observation::*;
pub use controller::*;
pub use debug::*;
pub use fps::*;
pub use gimbal_pid::*;
pub use help::*;
pub use input::*;
pub use notice::*;
pub use performance::*;
pub use projectile::*;
pub use uav::*;

use bevy::prelude::*;

#[derive(SystemSet, Clone, PartialEq, Eq, Hash, Debug)]
pub enum GameplaySystems {
    Input,
    GameLogic,
    Camera,
    Cleanup,
}
