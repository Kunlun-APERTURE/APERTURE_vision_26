#![allow(dead_code)]
mod capture;
mod components;
mod config;
mod handler;
mod robomaster;
mod scene;
mod setup;
mod statistic;
mod systems;
mod telemetry;
mod util;

#[cfg(feature = "ros2")]
mod ros2;
#[cfg(feature = "talos")]
mod talos;
#[cfg(feature = "bench")]
mod bench;

use avian3d::prelude::*;
use bevy::diagnostic::{FrameTimeDiagnosticsPlugin, LogDiagnosticsPlugin};
use bevy::prelude::*;
use bevy::render::settings::{InstanceFlags, RenderCreation, WgpuSettings, WgpuSettingsPriority};
use bevy::render::{RenderPlugin, RenderSystems};
use bevy::window::PresentMode;
use bevy::winit::WinitSettings;
use bevy_inspector_egui::bevy_egui::EguiPlugin;
use bevy_inspector_egui::quick::WorldInspectorPlugin;
use std::sync::atomic::AtomicBool;

use crate::capture::effect::CameraLensEffectPlugin;
use crate::components::{
    CameraFocus, CameraMode, FollowingType, PictureInPictureState, ProjectileCooldown,
    SubscribeAutoAim,
};
use crate::config::{ConfigPlugin, SimulationConfig};
use crate::handler::{on_activate, on_hit};
use crate::robomaster::prelude::RoboMasterPlugins;
use crate::setup::setup;
use crate::statistic::ProjectileStatistics;
use crate::systems::{
    ChassisObservationFrame, ControllerState, FpsDisplayPlugin, GameplaySystems, HelpPlugin,
    NoticePlugin, PerformancePlugin, PreviousKinematicState, RobotInputs, change_appearance,
    cleanup_projectiles, clear_controller_input, controller_dart_just_pressed,
    controller_shoot_pressed, dart_launch, focus_controls, following_controls, freecam_controls,
    gimbal_controls, gimbal_pid_controls, inset_controls, projectile_aerodynamics,
    projectile_launch, remote_gimbal_controls, robot_vehicle_controls, route_robot_inputs,
    sample_gamepad_controller, sample_keyboard_controller, screenshot_on_f2, screenshot_saving,
    setup_picture_in_picture, setup_projectile, switch_slapper_control, uav_launch,
    update_auto_aim_subscription, update_camera_follow, update_camera_follow_slapper,
    update_chassis_observation, update_picture_in_picture,
};
use bevy_metalfx::MetalFxPlugin;

#[cfg(feature = "ros2")]
use crate::ros2::plugin::ROS2Plugin;
#[cfg(feature = "talos")]
use talos::TalosPlugin;

fn present_mode_from_config(value: &str) -> Option<PresentMode> {
    match value.trim().to_ascii_lowercase().as_str() {
        "auto_vsync" | "vsync" => Some(PresentMode::AutoVsync),
        "auto_no_vsync" | "no_vsync" | "novsync" => Some(PresentMode::AutoNoVsync),
        "fifo" => Some(PresentMode::Fifo),
        "fifo_relaxed" | "fifo-relaxed" => Some(PresentMode::FifoRelaxed),
        "mailbox" => Some(PresentMode::Mailbox),
        "immediate" => Some(PresentMode::Immediate),
        _ => None,
    }
}

fn is_wsl() -> bool {
    std::env::var_os("WSL_DISTRO_NAME").is_some()
        || std::env::var_os("WSL_INTEROP").is_some()
        || std::fs::read_to_string("/proc/sys/kernel/osrelease")
            .map(|release| release.to_ascii_lowercase().contains("microsoft"))
            .unwrap_or(false)
}

fn render_plugin_for_platform() -> RenderPlugin {
    if cfg!(target_os = "linux") && is_wsl() {
        return RenderPlugin {
            render_creation: RenderCreation::Automatic(Box::new(WgpuSettings {
                instance_flags: InstanceFlags::default()
                    | InstanceFlags::ALLOW_UNDERLYING_NONCOMPLIANT_ADAPTER,
                priority: WgpuSettingsPriority::Functionality,
                ..default()
            })),
            ..default()
        };
    }

    RenderPlugin::default()
}

fn fixed_time_from_config(config: &SimulationConfig) -> Time<Fixed> {
    Time::<Fixed>::from_hz(config.physics.fixed_hz.max(1.0))
}

/// `ControllerState` with the F5 auto-aim toggle optionally pre-armed.
///
/// The gimbal only follows an external solver (`/rm_gimbal/cmd` over ROS 2, or
/// the Talos shm path) while `SubscribeAutoAim` is set, and that flag mirrors
/// the F5 toggle every frame. A headless or scripted run has no keyboard, so
/// `DAEDALUS_AUTO_AIM=1` seeds the initial state of that same toggle. Pressing
/// F5 later still turns it back off — this only changes where it starts.
fn controller_state_with_auto_aim_default() -> ControllerState {
    let mut state = ControllerState::default();
    let enabled = std::env::var("DAEDALUS_AUTO_AIM")
        .map(|v| {
            matches!(
                v.trim().to_ascii_lowercase().as_str(),
                "1" | "true" | "yes" | "on"
            )
        })
        .unwrap_or(false);
    if enabled {
        info!("DAEDALUS_AUTO_AIM set: starting with the F5 auto-aim toggle ARMED");
        state.seed_auto_aim(true);
    }
    state
}

#[cfg(feature = "talos")]
fn should_enable_talos_plugin(_app: &App) -> bool {
    #[cfg(feature = "ros2")]
    let ros_capture_active = _app
        .world()
        .contains_resource::<crate::ros2::capture::RosCaptureContext>();
    #[cfg(not(feature = "ros2"))]
    let ros_capture_active = false;

    let force_talos_capture = std::env::var("DAEDALUS_FORCE_TALOS_CAPTURE")
        .map(|v| v == "1")
        .unwrap_or(false);

    !ros_capture_active || force_talos_capture
}

fn main() {
    let config = SimulationConfig::default();
    let present_mode = present_mode_from_config(&config.window.present_mode).unwrap_or_else(|| {
        warn!(
            "Unknown window.present_mode {:?}, falling back to auto_no_vsync",
            config.window.present_mode
        );
        PresentMode::AutoNoVsync
    });
    let mut app = App::new();
    app.add_plugins((
        DefaultPlugins
            .set(WindowPlugin {
                primary_window: Some(Window {
                    present_mode,
                    fit_canvas_to_parent: true,
                    ..default()
                }),
                ..default()
            })
            .set(render_plugin_for_platform()),
        PhysicsPlugins::default(),
    ));
    app.insert_resource(WinitSettings::continuous());

    if config.debug.egui {
        app.add_plugins(EguiPlugin::default());
        if config.debug.inspector {
            app.add_plugins(WorldInspectorPlugin::new());
        }
    }

    app.add_plugins(RoboMasterPlugins)
        .add_plugins(MetalFxPlugin)
        .add_plugins(CameraLensEffectPlugin)
        .add_plugins(HelpPlugin)
        .add_plugins(FpsDisplayPlugin)
        .add_plugins(NoticePlugin)
        .add_plugins(crate::scene::ScenePlugin)
        .add_plugins(ConfigPlugin)
        .add_plugins(PerformancePlugin)
        .init_resource::<CameraMode>()
        .init_resource::<CameraFocus>()
        .init_resource::<PictureInPictureState>()
        .init_resource::<ProjectileStatistics>()
        .init_resource::<ChassisObservationFrame>()
        .init_resource::<PreviousKinematicState>()
        .init_resource::<RobotInputs>()
        .insert_resource(controller_state_with_auto_aim_default())
        .register_type::<ProjectileStatistics>()
        .insert_resource(Gravity(Vec3::NEG_Y * 9.81))
        .insert_resource(SubstepCount(config.physics.substep_count))
        .insert_resource(fixed_time_from_config(&config))
        .insert_resource(SubscribeAutoAim(AtomicBool::new(false)))
        .insert_resource(ProjectileCooldown(Timer::from_seconds(
            config.projectile.cooldown,
            TimerMode::Once,
        )))
        .add_systems(Startup, (setup, setup_projectile, setup_picture_in_picture))
        .add_observer(on_hit)
        .add_observer(on_activate)
        .configure_sets(
            Update,
            (
                GameplaySystems::Input,
                GameplaySystems::GameLogic,
                GameplaySystems::Camera,
                GameplaySystems::Cleanup,
            )
                .chain(),
        )
        .add_systems(
            Update,
            (
                // Input phase
                (
                    clear_controller_input,
                    sample_keyboard_controller,
                    sample_gamepad_controller,
                    update_auto_aim_subscription,
                    following_controls,
                    focus_controls,
                    inset_controls,
                    switch_slapper_control,
                    // Route the two hand-driven slots to their robots first, then
                    // drive every robot from the resulting per-robot table. The
                    // benchmark scenario evaluator (bench feature) edits the same
                    // table between these two, which is what makes scripted and
                    // hand-driven motion share one physics path.
                    route_robot_inputs,
                    robot_vehicle_controls,
                    gimbal_controls,
                    gimbal_pid_controls.run_if(|enabled: Res<SubscribeAutoAim>, config: Res<SimulationConfig>| {
                        enabled.load(std::sync::atomic::Ordering::Acquire) && !config.vehicle.gimbal_pid.fixed_update
                    }),
                    remote_gimbal_controls,
                )
                    .chain()
                    .in_set(GameplaySystems::Input),
                // GameLogic phase
                change_appearance.in_set(GameplaySystems::GameLogic),
                // Camera phase
                (
                    freecam_controls.run_if(|mode: Res<CameraMode>| mode.0 == FollowingType::Free),
                    update_camera_follow
                        .run_if(|mode: Res<CameraMode>| mode.0 != FollowingType::Free)
                        .run_if(|focus: Res<CameraFocus>| *focus == CameraFocus::Own),
                    update_camera_follow_slapper
                        .run_if(|mode: Res<CameraMode>| mode.0 != FollowingType::Free)
                        .run_if(|focus: Res<CameraFocus>| *focus == CameraFocus::Slapper),
                    update_picture_in_picture,
                )
                    .in_set(GameplaySystems::Camera)
                    .before(RenderSystems::Render),
                // Cleanup phase
                (
                    cleanup_projectiles,
                    screenshot_on_f2
                        .run_if(|input: Res<ButtonInput<KeyCode>>| input.just_pressed(KeyCode::F2)),
                    screenshot_saving,
                )
                    .in_set(GameplaySystems::Cleanup),
            ),
        )
        .add_systems(
            PostUpdate,
            update_chassis_observation.after(TransformSystems::Propagate),
        )
        .add_systems(
            PostUpdate,
            projectile_launch
                .after(TransformSystems::Propagate)
                .run_if(controller_shoot_pressed),
        )
        .add_systems(
            PostUpdate,
            dart_launch
                .after(TransformSystems::Propagate)
                .run_if(controller_dart_just_pressed),
        )
        .add_systems(PostUpdate, uav_launch.after(TransformSystems::Propagate))
        .add_systems(FixedUpdate, projectile_aerodynamics)
        .add_systems(FixedUpdate, gimbal_pid_controls.run_if(
            |enabled: Res<SubscribeAutoAim>, config: Res<SimulationConfig>| {
                enabled.load(std::sync::atomic::Ordering::Acquire) && config.vehicle.gimbal_pid.fixed_update
            }));

    // Always registered: the FPS overlay reads these diagnostics even when the
    // console logger (`debug.diagnostics`) is off.
    app.add_plugins(FrameTimeDiagnosticsPlugin::default());

    if config.debug.diagnostics {
        app.add_plugins(LogDiagnosticsPlugin::default());
    }

    #[cfg(feature = "ros2")]
    {
        app.add_plugins(ROS2Plugin::default());
        info!("ROS2 integration enabled");
    }
    #[cfg(not(feature = "ros2"))]
    {
        info!("ROS2 integration disabled");
    }

    // After `ROS2Plugin`, whose build inserts the topic publishers this reads.
    // `bench` implies `ros2`, so there is no `not(ros2)` case to handle.
    #[cfg(feature = "bench")]
    {
        app.add_plugins(bench::BenchPlugin);
        info!("benchmark v2 integration enabled");
    }

    #[cfg(feature = "talos")]
    {
        if should_enable_talos_plugin(&app) {
            app.add_plugins(TalosPlugin::default());
            info!("talos integration enabled");
        } else {
            info!(
                "talos integration skipped: ROS2 capture already active \
                 (set DAEDALUS_FORCE_TALOS_CAPTURE=1 to override)"
            );
        }
    }

    app.run();
}
