#ifndef AUTO_AIM__YOLO_HPP
#define AUTO_AIM__YOLO_HPP

#include <opencv2/opencv.hpp>
#include <nlohmann/json.hpp>

#include "armor.hpp"

namespace auto_aim
{
class YOLOBase
{
public:
  virtual ~YOLOBase() = default;
  virtual void enable_diagnostics(bool) {}
  virtual nlohmann::json diagnostics() const { return nullptr; }
  virtual nlohmann::json summary() const { return nullptr; }
  virtual std::list<Armor> detect(const cv::Mat & img, int frame_count) = 0;

  virtual std::list<Armor> postprocess(
    double scale, cv::Mat & output, const cv::Mat & bgr_img, int frame_count) = 0;
};

class YOLO
{
public:
  YOLO(const std::string & config_path, bool debug = true);
  void enable_diagnostics(bool enabled) { yolo_->enable_diagnostics(enabled); }
  nlohmann::json diagnostics() const { return yolo_->diagnostics(); }
  nlohmann::json summary() const { return yolo_->summary(); }

  std::list<Armor> detect(const cv::Mat & img, int frame_count = -1);

  std::list<Armor> postprocess(
    double scale, cv::Mat & output, const cv::Mat & bgr_img, int frame_count);

private:
  std::unique_ptr<YOLOBase> yolo_;
};

}  // namespace auto_aim

#endif  // AUTO_AIM__YOLO_HPP