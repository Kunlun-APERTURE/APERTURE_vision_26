#include "shooter.hpp"

#include <yaml-cpp/yaml.h>

#include "tools/logger.hpp"
#include "tools/math_tools.hpp"

namespace auto_aim
{
Shooter::Shooter(const std::string & config_path) : last_command_{false, false, 0, 0}
{
  auto yaml = YAML::LoadFile(config_path);
  continuity_=ContinuityConfig::read(config_path);
  first_tolerance_ = yaml["first_tolerance"].as<double>() / 57.3;    // degree to rad
  second_tolerance_ = yaml["second_tolerance"].as<double>() / 57.3;  // degree to rad
  judge_distance_ = yaml["judge_distance"].as<double>();
  auto_fire_ = yaml["auto_fire"].as<bool>();
}

bool Shooter::shoot(
  const io::Command & command, const auto_aim::Aimer & aimer,
  const std::list<auto_aim::Target> & targets, const Eigen::Vector3d & gimbal_pos)
{
  if (!command.control || targets.empty() || !auto_fire_) return false;

  auto target_x = targets.front().ekf_x()[0];
  auto target_y = targets.front().ekf_x()[2];
  auto tolerance = std::sqrt(tools::square(target_x) + tools::square(target_y)) > judge_distance_
                     ? second_tolerance_
                     : first_tolerance_;
  // tools::logger()->debug("d(command.yaw) is {:.4f}", std::abs(last_command_.yaw - command.yaw));
  if (
    std::abs(last_command_.yaw - command.yaw) < tolerance * 2 &&  //此时认为command突变不应该射击
    std::abs(gimbal_pos[0] - last_command_.yaw) < tolerance &&    //应该减去上一次command的yaw值
    aimer.debug_aim_point.valid) {
    last_command_ = command;
    return true;
  }

  last_command_ = command;
  return false;
}

bool Shooter::shoot_current(const io::Command &command,const FireContext &c)
{
  const double yaw_error=tools::limit_rad(command.yaw-c.yaw);
  const double pitch_error=-command.pitch-c.elevation;
  const double dt=tools::delta_time(c.capture_time,previous_time_);
  const double radians=CV_PI/180.;
  double angle_residual=0;
  bool discontinuity=!(continuity_.robust_v3?previous_command_valid_:previous_valid_) || dt<=0 || dt>.1 || c.generation!=previous_generation_ || (!continuity_.robust_v3 && c.plate_id!=previous_plate_);
  if((continuity_.robust_v3?previous_command_valid_:previous_valid_) && dt>0 && dt<=.1) {
    const double yaw_delta=tools::limit_rad(command.yaw-last_command_.yaw);
    const double pitch_delta=command.pitch-last_command_.pitch;
    angle_residual=std::hypot(tools::limit_rad(yaw_delta-previous_yaw_rate_*dt),pitch_delta-previous_pitch_rate_*dt);
    if(angle_residual>continuity_.fire_jump_deg*radians)discontinuity=true;
    previous_yaw_rate_=yaw_delta/dt;previous_pitch_rate_=pitch_delta/dt;
  } else {previous_yaw_rate_=0;previous_pitch_rate_=0;}
  const double yaw_tolerance=continuity_.robust_v3 && c.target_half_width_rad>=0 ?
    std::min(continuity_.fire_yaw_max_deg*radians,c.target_half_width_rad*.9) : continuity_.fire_tolerance_deg*radians;
  const bool target_face_valid=!(continuity_.robust_v3 && c.target_half_width_rad>=0) || c.target_half_width_rad>1e-6;
  const bool command_valid=target_face_valid && command.control && std::isfinite(command.yaw) && std::isfinite(command.pitch)
    && c.plate_id>=0;
  const bool valid=command_valid && c.tracking && c.measurement_fresh;
  const bool pose_valid=std::isfinite(c.yaw) && std::isfinite(c.elevation)
    && c.pose_age_s>=0 && c.pose_age_s<=continuity_.fire_pose_max_age_s;
  const bool aligned=pose_valid && std::abs(yaw_error)<=yaw_tolerance
    && std::abs(pitch_error)<=continuity_.fire_tolerance_deg*radians;
  const bool stable_input=valid && pose_valid && (aligned || (continuity_.robust_v3 && !continuity_.fire_stability_requires_alignment));
  const double good_age=tools::delta_time(c.capture_time,last_good_time_);
  const bool held=continuity_.robust_v3 && !discontinuity && command_valid && pose_valid && (aligned || !continuity_.fire_stability_requires_alignment) && !valid
    && stable_time_s_>=continuity_.fire_stable_time_s && good_age>0 && good_age<=continuity_.fire_measurement_hold_s;
  if(discontinuity || !pose_valid || (!aligned && (!continuity_.robust_v3 || continuity_.fire_stability_requires_alignment)) || (!valid && !held)) {stable_frames_=0;stable_time_s_=0;}
  else if(valid) {++stable_frames_;if(continuity_.robust_v3?previous_good_:previous_aligned_)stable_time_s_+=dt;}
  if(stable_input)last_good_time_=c.capture_time;
  const bool recovered=continuity_.robust_v3 ? stable_time_s_>=continuity_.fire_stable_time_s : stable_frames_>=continuity_.fire_recovery_frames;
  const bool advice=auto_fire_ && valid && aligned && recovered;
  diagnostics={{"pose_valid",pose_valid},{"stability_requires_alignment",continuity_.fire_stability_requires_alignment},{"qualification_held",held},{"last_good_age_s",good_age},{"yaw_tolerance_rad",yaw_tolerance},{"target_half_width_rad",c.target_half_width_rad},{"target_face_valid",target_face_valid},{"yaw_error_rad",yaw_error},{"pitch_error_rad",pitch_error},{"pose_age_s",c.pose_age_s},
    {"command_residual_deg",angle_residual/radians},{"discontinuity",discontinuity},
    {"stable_time_s",stable_time_s_},{"plate_changed",c.plate_id!=previous_plate_},{"aligned",aligned},{"valid",valid},{"stable_frames",stable_frames_},{"eligible",advice}};
  previous_command_valid_=command_valid;previous_good_=stable_input;previous_aligned_=aligned;previous_valid_=valid;previous_time_=c.capture_time;last_command_=command;
  previous_generation_=c.generation;previous_plate_=c.plate_id;
  return advice;
}

}  // namespace auto_aim
