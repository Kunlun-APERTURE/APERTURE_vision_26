#pragma once
#include <Eigen/Dense>
#include <chrono>
#include <deque>

namespace auto_aim {
// Independent CV translation for one physical plate. Normal/geometry noise
// cannot move this state; identity changes select another filter explicitly.
struct PlateFilter {
  Eigen::Matrix<double,6,1> x=Eigen::Matrix<double,6,1>::Zero();
  Eigen::Matrix<double,6,6> P=Eigen::Matrix<double,6,6>::Identity();
  struct Sample {double t;Eigen::Vector3d position;Eigen::Matrix3d covariance;};
  std::deque<Sample> bootstrap_samples;
  bool bootstrap_enabled=false,bootstrap_finished=false;
  double elapsed_s=0,bootstrap_window_s=.2;
  bool initialized=false;
  double age_s=1e6,area=0;
  Eigen::Vector3d position() const {return {x[0],x[2],x[4]};}
  Eigen::Vector3d velocity() const {return {x[1],x[3],x[5]};}
  Eigen::Matrix3d position_covariance() const {
    Eigen::Matrix3d result;
    for(int i=0;i<3;++i)for(int j=0;j<3;++j)result(i,j)=P(2*i,2*j);
    return result;
  }
  void predict(double dt,double variance,double radial_variance,double vertical_variance) {
    if(!initialized || dt<=0)return;
    auto F=Eigen::Matrix<double,6,6>::Identity().eval();
    auto Q=Eigen::Matrix<double,6,6>::Zero().eval();
    Eigen::Vector3d radial(position().x(),position().y(),0);
    if(radial.norm()<1e-6)radial=Eigen::Vector3d::UnitX();
    radial.normalize();
    const Eigen::Vector3d lateral(-radial.y(),radial.x(),0);
    const Eigen::Matrix3d acceleration=radial_variance*radial*radial.transpose()
      +variance*lateral*lateral.transpose()
      +vertical_variance*Eigen::Vector3d::UnitZ()*Eigen::Vector3d::UnitZ().transpose();
    for(int i=0;i<3;++i) {
      F(2*i,2*i+1)=dt;
      for(int j=0;j<3;++j) {
        Q(2*i,2*j)=acceleration(i,j)*std::pow(dt,4)/4;
        Q(2*i,2*j+1)=Q(2*i+1,2*j)=acceleration(i,j)*std::pow(dt,3)/2;
        Q(2*i+1,2*j+1)=acceleration(i,j)*dt*dt;
      }
    }
    elapsed_s+=dt;
    x=F*x;P=(F*P*F.transpose()+Q).eval();age_s+=dt;
  }
  bool update(const Eigen::Vector3d &observation,const Eigen::Matrix3d &R,double image_area) {
    if(!observation.allFinite() || observation.norm()<1e-6 || !R.allFinite())return false;
    const Eigen::Vector3d &position=observation;
    if(!initialized) {
      for(int i=0;i<3;++i)x[2*i]=position[i];
      P.setZero();
      for(int i=0;i<3;++i)for(int j=0;j<3;++j)P(2*i,2*j)=R(i,j);
      for(int i=0;i<3;++i)P(2*i+1,2*i+1)=1.;
      if(bootstrap_enabled)bootstrap_samples.push_back({elapsed_s,observation,R});
      initialized=true;age_s=0;area=image_area;return true;
    }
    Eigen::Matrix<double,3,6> H=Eigen::Matrix<double,3,6>::Zero();
    for(int i=0;i<3;++i)H(i,2*i)=1;
    const Eigen::Matrix3d S=H*P*H.transpose()+R;
    Eigen::LDLT<Eigen::Matrix3d> factor(S);
    if(factor.info()!=Eigen::Success || !factor.isPositive())return false;
    Eigen::Matrix<double,6,3> K=factor.solve(H*P).transpose();
    const auto next=(x+K*(position-H*x)).eval();
    const auto A=(Eigen::Matrix<double,6,6>::Identity()-K*H).eval();
    const auto covariance=(A*P*A.transpose()+K*R*K.transpose()).eval();
    if(!next.allFinite() || !covariance.allFinite())return false;
    x=next;P=(covariance+covariance.transpose()).eval()*.5;
    if(bootstrap_enabled && !bootstrap_finished) {
      if(age_s>.1) {bootstrap_samples.clear();bootstrap_finished=true;}
      else bootstrap_samples.push_back({elapsed_s,observation,R});
      if(bootstrap_samples.size()>=5 && elapsed_s-bootstrap_samples.front().t>=bootstrap_window_s) {
        Eigen::Matrix<double,6,6> information=Eigen::Matrix<double,6,6>::Zero();
        Eigen::Matrix<double,6,1> rhs=Eigen::Matrix<double,6,1>::Zero();
        for(const auto &sample:bootstrap_samples) {
          Eigen::Matrix<double,3,6> design=Eigen::Matrix<double,3,6>::Zero();
          for(int i=0;i<3;++i) {design(i,2*i)=1;design(i,2*i+1)=sample.t-elapsed_s;}
          Eigen::LDLT<Eigen::Matrix3d> factor(sample.covariance);
          if(factor.info()!=Eigen::Success || !factor.isPositive())continue;
          information+=design.transpose()*factor.solve(design);rhs+=design.transpose()*factor.solve(sample.position);
        }
        Eigen::LDLT<Eigen::Matrix<double,6,6>> factor(information);
        if(factor.info()==Eigen::Success && factor.isPositive()) {
          const auto estimate=factor.solve(rhs).eval();
          const auto next_covariance=factor.solve(Eigen::Matrix<double,6,6>::Identity()).eval();
          if(estimate.allFinite() && next_covariance.allFinite() && Eigen::Vector3d(estimate[1],estimate[3],estimate[5]).norm()<8.) {
            x=estimate;P=(next_covariance+next_covariance.transpose()).eval()*.5;
          }
        }
        bootstrap_finished=true;bootstrap_samples.clear();
      }
    }
    age_s=0;area=image_area;return true;
  }
};
}
