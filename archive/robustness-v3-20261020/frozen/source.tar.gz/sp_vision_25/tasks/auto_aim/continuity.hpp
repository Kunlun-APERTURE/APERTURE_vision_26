#pragma once
#include <cmath>
#include <stdexcept>
#include <string>
#include <yaml-cpp/yaml.h>
namespace auto_aim {
// Generic algorithm options: no simulator or transport types enter the core.
struct ContinuityConfig {
  bool enabled = false;
  bool fire_enabled = false;
  bool robust_v3 = false;
  double strong_confidence=.8;
  bool velocity_bootstrap=false;
  bool fire_stability_requires_alignment=true;
  double fire_yaw_max_deg=1.0;
  double fire_measurement_hold_s=.1;
  double fire_stable_time_s=.04;
  double velocity_bootstrap_window_s=.2;
  double preferred_plate_hysteresis=1.15;
  double translation_variance = 30.0;
  double rotation_variance = 10.0;
  double maneuver_translation_variance = 100.0;
  double maneuver_rotation_variance = 400.0;
  double innovation_limit = 13.276704135987622; // chi2.ppf(.99, 4)
  double reprojection_max_px = 8.0;
  double trusted_timeout_s = .25;
  double bearing_noise_rad = .003;
  double range_noise_m = .15;
  double radial_acceleration_variance = .3;
  double vertical_acceleration_variance = .1;
  double fire_tolerance_deg = .5;
  double fire_pose_max_age_s = .05;
  double fire_jump_deg = 1.0;
  int fire_recovery_frames = 3;
  static ContinuityConfig read(const std::string &path) {
    ContinuityConfig c;
    auto root=YAML::LoadFile(path);
    const auto profile=root["algorithm_profile"] ? root["algorithm_profile"].as<std::string>() : "legacy";
    if (profile!="legacy" && profile!="tracking_v2" && profile!="tracking_fire_v2" && profile!="tracking_v3" && profile!="tracking_fire_v3")
      throw std::invalid_argument("Unknown algorithm_profile");
    c.enabled=profile!="legacy"; c.fire_enabled=profile=="tracking_fire_v2" || profile=="tracking_fire_v3";
    c.robust_v3=profile=="tracking_v3" || profile=="tracking_fire_v3";
    auto n=root["continuity_v2"];
    if(n) {
#define OPTION(field) if(n[#field]) c.field=n[#field].as<decltype(c.field)>()
      OPTION(translation_variance); OPTION(rotation_variance);
      OPTION(maneuver_translation_variance); OPTION(maneuver_rotation_variance);
      OPTION(innovation_limit); OPTION(reprojection_max_px); OPTION(trusted_timeout_s);
      OPTION(bearing_noise_rad); OPTION(range_noise_m);
      OPTION(radial_acceleration_variance); OPTION(vertical_acceleration_variance);
      OPTION(fire_tolerance_deg); OPTION(fire_pose_max_age_s); OPTION(fire_jump_deg);
      OPTION(fire_recovery_frames);
#undef OPTION
    }
    for(double v:{c.translation_variance,c.rotation_variance,c.maneuver_translation_variance,
        c.maneuver_rotation_variance,c.innovation_limit,c.reprojection_max_px,c.trusted_timeout_s,
        c.bearing_noise_rad,c.range_noise_m,c.radial_acceleration_variance,c.vertical_acceleration_variance,
        c.fire_tolerance_deg,c.fire_pose_max_age_s,c.fire_jump_deg})
      if(!std::isfinite(v)||v<=0) throw std::invalid_argument("Invalid continuity_v2 parameter");
    if(c.fire_recovery_frames<1) throw std::invalid_argument("Invalid fire recovery count");
    if(root["min_confidence"])c.strong_confidence=root["min_confidence"].as<double>();
    auto v3=root["robustness_v3"];
    if(v3) {
      if(v3["velocity_bootstrap"])c.velocity_bootstrap=v3["velocity_bootstrap"].as<bool>();
      if(v3["radial_acceleration_variance"] && c.robust_v3)c.radial_acceleration_variance=v3["radial_acceleration_variance"].as<double>();
      if(v3["velocity_bootstrap_window_s"])c.velocity_bootstrap_window_s=v3["velocity_bootstrap_window_s"].as<double>();
      if(v3["preferred_plate_hysteresis"])c.preferred_plate_hysteresis=v3["preferred_plate_hysteresis"].as<double>();
      if(v3["fire_stability_requires_alignment"])c.fire_stability_requires_alignment=v3["fire_stability_requires_alignment"].as<bool>();
      if(v3["fire_measurement_hold_s"])c.fire_measurement_hold_s=v3["fire_measurement_hold_s"].as<double>();
      if(v3["fire_yaw_max_deg"])c.fire_yaw_max_deg=v3["fire_yaw_max_deg"].as<double>();
      if(v3["fire_stable_time_s"])c.fire_stable_time_s=v3["fire_stable_time_s"].as<double>();
    }
    for(double v:{c.radial_acceleration_variance,c.velocity_bootstrap_window_s,c.preferred_plate_hysteresis,c.fire_stable_time_s,c.fire_yaw_max_deg,c.fire_measurement_hold_s})
      if(!std::isfinite(v)||v<=0)throw std::invalid_argument("Invalid robustness_v3 parameter");
    return c;
  }
};
}
