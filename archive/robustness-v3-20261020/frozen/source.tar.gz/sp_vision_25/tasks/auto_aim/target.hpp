#ifndef AUTO_AIM__TARGET_HPP
#define AUTO_AIM__TARGET_HPP

#include <Eigen/Dense>
#include <chrono>
#include <optional>
#include <queue>
#include <string>
#include <vector>

#include "armor.hpp"
#include "continuity.hpp"
#include "plate_filter.hpp"
#include <nlohmann/json.hpp>
#include "tools/extended_kalman_filter.hpp"

namespace auto_aim
{

class Target
{
public:
  ArmorName name;
  ArmorType armor_type;
  ArmorPriority priority;
  bool jumped;
  int last_id;  // debug only
  unsigned generation=0;

  Target() = default;
  Target(
    const Armor & armor, std::chrono::steady_clock::time_point t, double radius, int armor_num,
    Eigen::VectorXd P0_dig, ContinuityConfig continuity = {});
  Target(double x, double vyaw, double radius, double h);

  void predict(std::chrono::steady_clock::time_point t);
  void predict(double dt);
  void update(const Armor & armor);
  struct Assessment {
    tools::Innovation innovation;
    Eigen::MatrixXd H,R;
    Eigen::Vector3d position_residual=Eigen::Vector3d::Zero();
    bool quality=false;
    double cost=1e20;
    std::string reason="unassessed";
  };
  Assessment assess(const Armor &armor,int id) const;
  bool update_robust(const std::vector<std::pair<Armor,int>> &observations);
  int armor_count() const { return armor_num_; }
  int preferred_plate() const { return preferred_plate_; }
  std::vector<Eigen::Vector3d> plate_velocities() const;
  bool maneuvering() const { return translation_maneuver_ || rotation_maneuver_; }
  nlohmann::json continuity_diagnostics;

  Eigen::VectorXd ekf_x() const;
  const tools::ExtendedKalmanFilter & ekf() const;
  std::vector<Eigen::Vector4d> armor_xyza_list() const;

  bool diverged() const;

  bool convergened();

  bool isinit = false;

  bool checkinit();

private:
  int armor_num_;
  int switch_count_;
  int update_count_;

  bool is_switch_, is_converged_;

  tools::ExtendedKalmanFilter ekf_;
  std::chrono::steady_clock::time_point t_;
  ContinuityConfig continuity_;
  bool translation_maneuver_=false,rotation_maneuver_=false;
  std::vector<PlateFilter> plate_filters_;
  int preferred_plate_=-1;
  void sync_translation();
  int translation_evidence_=0,rotation_evidence_=0,quiet_count_=0,evidence_id_=-1;
  Eigen::Vector2d previous_motion_innovation_=Eigen::Vector2d::Zero();
  double previous_angle_residual_=0;
  double previous_orientation_step_=0;
  std::chrono::steady_clock::time_point evidence_time_{};

  void update_ypda(const Armor & armor, int id);  // yaw pitch distance angle

  Eigen::Vector3d h_armor_xyz(const Eigen::VectorXd & x, int id) const;
  Eigen::MatrixXd h_jacobian(const Eigen::VectorXd & x, int id) const;
};

}  // namespace auto_aim

#endif  // AUTO_AIM__TARGET_HPP
