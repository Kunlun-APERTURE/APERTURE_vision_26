#ifndef AUTO_AIM__AIMER_HPP
#define AUTO_AIM__AIMER_HPP

#include <Eigen/Dense>
#include <chrono>
#include <list>

#include "io/cboard.hpp"
#include "io/command.hpp"
#include "target.hpp"

namespace auto_aim
{

struct AimPoint
{
  bool valid;
  Eigen::Vector4d xyza;
};

class Aimer
{
public:
  AimPoint debug_aim_point;
  explicit Aimer(const std::string & config_path);
  // Generic calibrated muzzle translation, in the same world-aligned frame as
  // Target. Zero preserves existing hardware callers and their calibration.
  void set_muzzle_position(const Eigen::Vector3d & position) { muzzle_position_ = position; }
  // Optional deterministic capture-to-evaluation age, for read-only replay.
  void set_processing_age(double seconds) { processing_age_=seconds; }
  int selected_plate_id=-1;
  double prediction_horizon_s=0;
  io::Command aim(
    std::list<Target> targets, std::chrono::steady_clock::time_point timestamp, double bullet_speed,
    bool to_now = true);

  io::Command aim(
    std::list<Target> targets, std::chrono::steady_clock::time_point timestamp, double bullet_speed,
    io::ShootMode shoot_mode, bool to_now = true);

private:
  Eigen::Vector3d muzzle_position_ = Eigen::Vector3d::Zero();
  double yaw_offset_;
  std::optional<double> left_yaw_offset_, right_yaw_offset_;
  double pitch_offset_;
  double comming_angle_;
  double leaving_angle_;
  double lock_id_ = -1;
  double high_speed_delay_time_;
  double low_speed_delay_time_;
  double decision_speed_;
  ContinuityConfig continuity_;
  unsigned generation_=0;
  std::optional<double> processing_age_;

  AimPoint choose_aim_point(const Target & target);
};

}  // namespace auto_aim

#endif  // AUTO_AIM__AIMER_HPP
