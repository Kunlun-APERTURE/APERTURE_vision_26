#include "target.hpp"

#include <numeric>
#include <algorithm>

#include "tools/logger.hpp"
#include "tools/math_tools.hpp"

namespace auto_aim
{
Target::Target(
  const Armor & armor, std::chrono::steady_clock::time_point t, double radius, int armor_num,
  Eigen::VectorXd P0_dig, ContinuityConfig continuity)
: name(armor.name),
  armor_type(armor.type),
  jumped(false),
  last_id(0),
  update_count_(0),
  armor_num_(armor_num),
  t_(t),
  is_switch_(false),
  is_converged_(false),
  switch_count_(0)
{
  continuity_=continuity;
  auto r = radius;
  priority = armor.priority;
  const Eigen::VectorXd & xyz = armor.xyz_in_world;
  const Eigen::VectorXd & ypr = armor.ypr_in_world;

  // 旋转中心的坐标
  auto center_x = xyz[0] + r * std::cos(ypr[0]);
  auto center_y = xyz[1] + r * std::sin(ypr[0]);
  auto center_z = xyz[2];

  // x vx y vy z vz a w r l h
  // a: angle
  // w: angular velocity
  // l: r2 - r1
  // h: z2 - z1
  Eigen::VectorXd x0{{center_x, 0, center_y, 0, center_z, 0, ypr[0], 0, r, 0, 0}};  //初始化预测量
  Eigen::MatrixXd P0 = P0_dig.asDiagonal();
  if(continuity_.enabled) {
    // Geometry is weakly observable from one plate. It must not absorb a noisy
    // pose by creating a negative radius and resetting the complete track.
    P0(8,8)=.0001; P0(9,9)=.0001; P0(10,10)=.0001;
    P0(7,7)=1.;
  }

  // 防止夹角求和出现异常值
  auto x_add = [](const Eigen::VectorXd & a, const Eigen::VectorXd & b) -> Eigen::VectorXd {
    Eigen::VectorXd c = a + b;
    c[6] = tools::limit_rad(c[6]);
    return c;
  };

  ekf_ = tools::ExtendedKalmanFilter(x0, P0, x_add);  //初始化滤波器（预测量、预测量协方差）
  if(continuity_.enabled) {
    plate_filters_.resize(armor_num_);
    for(auto &plate:plate_filters_) {
      plate.bootstrap_enabled=continuity_.robust_v3 && continuity_.velocity_bootstrap;
      plate.bootstrap_window_s=continuity_.velocity_bootstrap_window_s;
    }
    Eigen::Matrix3d initial_R=Eigen::Matrix3d::Identity()*.01;
    if(continuity_.robust_v3) {
      const auto quality=assess(armor,0);
      const Eigen::Matrix3d inverse=tools::xyz2ypd_jacobian(xyz).inverse();
      initial_R=inverse*quality.R.topLeftCorner(3,3)*inverse.transpose();
    }
    plate_filters_[0].update(xyz,initial_R,std::abs(cv::contourArea(armor.points)));
    preferred_plate_=0;
  }
}

Target::Target(double x, double vyaw, double radius, double h) : armor_num_(4)
{
  Eigen::VectorXd x0{{x, 0, 0, 0, 0, 0, 0, vyaw, radius, 0, h}};
  Eigen::VectorXd P0_dig{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
  Eigen::MatrixXd P0 = P0_dig.asDiagonal();

  // 防止夹角求和出现异常值
  auto x_add = [](const Eigen::VectorXd & a, const Eigen::VectorXd & b) -> Eigen::VectorXd {
    Eigen::VectorXd c = a + b;
    c[6] = tools::limit_rad(c[6]);
    return c;
  };

  ekf_ = tools::ExtendedKalmanFilter(x0, P0, x_add);  //初始化滤波器（预测量、预测量协方差）
}

void Target::predict(std::chrono::steady_clock::time_point t)
{
  auto dt = tools::delta_time(t, t_);
  predict(dt);
  t_ = t;
}

void Target::predict(double dt)
{
  // 状态转移矩阵
  // clang-format off
  Eigen::MatrixXd F{
    {1, dt,  0,  0,  0,  0,  0,  0,  0,  0,  0},
    {0,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0},
    {0,  0,  1, dt,  0,  0,  0,  0,  0,  0,  0},
    {0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0},
    {0,  0,  0,  0,  1, dt,  0,  0,  0,  0,  0},
    {0,  0,  0,  0,  0,  1,  0,  0,  0,  0,  0},
    {0,  0,  0,  0,  0,  0,  1, dt,  0,  0,  0},
    {0,  0,  0,  0,  0,  0,  0,  1,  0,  0,  0},
    {0,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0},
    {0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  0},
    {0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1}
  };
  // clang-format on

  // Piecewise White Noise Model
  // https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python/blob/master/07-Kalman-Filter-Math.ipynb
  double v1, v2;
  if (name == ArmorName::outpost) {
    v1 = 10;   // 前哨站加速度方差
    v2 = 0.1;  // 前哨站角加速度方差
  } else {
    v1 = 100;  // 加速度方差
    v2 = 400;  // 角加速度方差
  }
  if(continuity_.enabled && name!=ArmorName::outpost) {
    v1=translation_maneuver_ ? continuity_.maneuver_translation_variance : continuity_.translation_variance;
    v2=rotation_maneuver_ ? continuity_.maneuver_rotation_variance : continuity_.rotation_variance;
  }
  auto a = dt * dt * dt * dt / 4;
  auto b = dt * dt * dt / 2;
  auto c = dt * dt;
  // 预测过程噪声偏差的方差
  // clang-format off
  Eigen::MatrixXd Q{
    {a * v1, b * v1,      0,      0,      0,      0,      0,      0, 0, 0, 0},
    {b * v1, c * v1,      0,      0,      0,      0,      0,      0, 0, 0, 0},
    {     0,      0, a * v1, b * v1,      0,      0,      0,      0, 0, 0, 0},
    {     0,      0, b * v1, c * v1,      0,      0,      0,      0, 0, 0, 0},
    {     0,      0,      0,      0, a * v1, b * v1,      0,      0, 0, 0, 0},
    {     0,      0,      0,      0, b * v1, c * v1,      0,      0, 0, 0, 0},
    {     0,      0,      0,      0,      0,      0, a * v2, b * v2, 0, 0, 0},
    {     0,      0,      0,      0,      0,      0, b * v2, c * v2, 0, 0, 0},
    {     0,      0,      0,      0,      0,      0,      0,      0, 0, 0, 0},
    {     0,      0,      0,      0,      0,      0,      0,      0, 0, 0, 0},
    {     0,      0,      0,      0,      0,      0,      0,      0, 0, 0, 0}
  };
  // clang-format on

  // 防止夹角求和出现异常值
  auto f = [&](const Eigen::VectorXd & x) -> Eigen::VectorXd {
    Eigen::VectorXd x_prior = F * x;
    x_prior[6] = tools::limit_rad(x_prior[6]);
    return x_prior;
  };

  // 前哨站转速特判
  if (this->convergened() && this->name == ArmorName::outpost && std::abs(this->ekf_.x[7]) > 2)
    this->ekf_.x[7] = this->ekf_.x[7] > 0 ? 2.51 : -2.51;

  ekf_.predict(F, Q, f);
  if(continuity_.enabled) {
    for(auto &plate:plate_filters_)plate.predict(dt,v1,continuity_.radial_acceleration_variance,
      continuity_.vertical_acceleration_variance);
    sync_translation();
  }
}

void Target::update(const Armor & armor)
{
  // 装甲板匹配
  int id;
  auto min_angle_error = 1e10;
  const std::vector<Eigen::Vector4d> & xyza_list = armor_xyza_list();

  std::vector<std::pair<Eigen::Vector4d, int>> xyza_i_list;
  for (int i = 0; i < armor_num_; i++) {
    xyza_i_list.push_back({xyza_list[i], i});
  }

  std::sort(
    xyza_i_list.begin(), xyza_i_list.end(),
    [](const std::pair<Eigen::Vector4d, int> & a, const std::pair<Eigen::Vector4d, int> & b) {
      Eigen::Vector3d ypd1 = tools::xyz2ypd(a.first.head(3));
      Eigen::Vector3d ypd2 = tools::xyz2ypd(b.first.head(3));
      return ypd1[2] < ypd2[2];
    });

  // 取前3个distance最小的装甲板
  for (int i = 0; i < 3; i++) {
    const auto & xyza = xyza_i_list[i].first;
    Eigen::Vector3d ypd = tools::xyz2ypd(xyza.head(3));
    auto angle_error = std::abs(tools::limit_rad(armor.ypr_in_world[0] - xyza[3])) +
                       std::abs(tools::limit_rad(armor.ypd_in_world[0] - ypd[0]));

    if (std::abs(angle_error) < std::abs(min_angle_error)) {
      id = xyza_i_list[i].second;
      min_angle_error = angle_error;
    }
  }

  if (id != 0) jumped = true;

  if (id != last_id) {
    is_switch_ = true;
  } else {
    is_switch_ = false;
  }

  if (is_switch_) switch_count_++;

  last_id = id;
  update_count_++;

  update_ypda(armor, id);
}

void Target::update_ypda(const Armor & armor, int id)
{
  //观测jacobi
  Eigen::MatrixXd H = h_jacobian(ekf_.x, id);
  // Eigen::VectorXd R_dig{{4e-3, 4e-3, 1, 9e-2}};
  auto center_yaw = std::atan2(armor.xyz_in_world[1], armor.xyz_in_world[0]);
  auto delta_angle = tools::limit_rad(armor.ypr_in_world[0] - center_yaw);
  Eigen::VectorXd R_dig{
    {4e-3, 4e-3, log(std::abs(delta_angle) + 1) + 1,
     log(std::abs(armor.ypd_in_world[2]) + 1) / 200 + 9e-2}};

  //测量过程噪声偏差的方差
  Eigen::MatrixXd R = R_dig.asDiagonal();

  // 定义非线性转换函数h: x -> z
  auto h = [&](const Eigen::VectorXd & x) -> Eigen::Vector4d {
    Eigen::VectorXd xyz = h_armor_xyz(x, id);
    Eigen::VectorXd ypd = tools::xyz2ypd(xyz);
    auto angle = tools::limit_rad(x[6] + id * 2 * CV_PI / armor_num_);
    return {ypd[0], ypd[1], ypd[2], angle};
  };

  // 防止夹角求差出现异常值
  auto z_subtract = [](const Eigen::VectorXd & a, const Eigen::VectorXd & b) -> Eigen::VectorXd {
    Eigen::VectorXd c = a - b;
    c[0] = tools::limit_rad(c[0]);
    c[1] = tools::limit_rad(c[1]);
    c[3] = tools::limit_rad(c[3]);
    return c;
  };

  const Eigen::VectorXd & ypd = armor.ypd_in_world;
  const Eigen::VectorXd & ypr = armor.ypr_in_world;
  Eigen::VectorXd z{{ypd[0], ypd[1], ypd[2], ypr[0]}};  //获得观测量

  ekf_.update(z, H, R, h, z_subtract);
}

Target::Assessment Target::assess(const Armor &armor,int id) const
{
  Assessment a;
  if(id<0 || id>=armor_num_ || !armor.pose_valid || !armor.xyz_in_world.allFinite()
      || !armor.ypr_in_world.allFinite() || !armor.ypd_in_world.allFinite()
      || !std::isfinite(armor.reprojection_rms_px)
      || armor.reprojection_rms_px>continuity_.reprojection_max_px) {
    a.reason="pose_quality"; return a;
  }
  const auto &plate=plate_filters_[id];
  const Eigen::Vector3d predicted=plate.initialized?plate.position():h_armor_xyz(ekf_.x,id);
  a.position_residual=armor.xyz_in_world-predicted;
  if(a.position_residual.norm()>.8) { a.reason="association_distance";return a; }
  a.H=Eigen::MatrixXd::Zero(4,11);a.H(3,6)=1;
  const double center_yaw=std::atan2(armor.xyz_in_world[1],armor.xyz_in_world[0]);
  const double delta=tools::limit_rad(armor.ypr_in_world[0]-center_yaw);
  const double quality=std::clamp(1+std::pow(armor.reprojection_rms_px/2.,2),1.,16.);
  // Image bearing is substantially better observed than the plate's normal
  // and depth. Keep their uncertainty separate instead of forcing translation
  // to wait for a noisy orientation estimate.
  Eigen::Vector4d diagonal(std::pow(continuity_.bearing_noise_rad,2),
    std::pow(continuity_.bearing_noise_rad,2),std::pow(continuity_.range_noise_m,2)*(1+std::abs(delta)),
    std::log(std::abs(armor.ypd_in_world[2])+1)/200+9e-2);
  a.R=(diagonal*quality).asDiagonal();
  Eigen::Vector4d z(armor.ypd_in_world[0],armor.ypd_in_world[1],armor.ypd_in_world[2],armor.ypr_in_world[0]);
  auto subtract=[](const Eigen::VectorXd &x,const Eigen::VectorXd &y)->Eigen::VectorXd {
    Eigen::VectorXd r=x-y;
    for(int i:{0,1,3}) r[i]=tools::limit_rad(r[i]);
    return r;
  };
  const auto ypd=tools::xyz2ypd(predicted);
  const Eigen::Vector4d expected(ypd[0],ypd[1],ypd[2],tools::limit_rad(ekf_.x[6]+id*2*CV_PI/armor_num_));
  a.innovation.residual=subtract(z,expected);
  a.innovation.covariance=a.R;
  const auto J=tools::xyz2ypd_jacobian(predicted);
  const Eigen::Matrix3d position_covariance=plate.initialized?plate.position_covariance():Eigen::Matrix3d::Identity()*.04;
  a.innovation.covariance.topLeftCorner(3,3)+=J*position_covariance*J.transpose();
  a.innovation.covariance(3,3)+=ekf_.P(6,6);
  Eigen::LDLT<Eigen::MatrixXd> factor(a.innovation.covariance);
  if(factor.info()==Eigen::Success && factor.isPositive() && a.innovation.residual.allFinite()) {
    a.innovation.nis=a.innovation.residual.dot(factor.solve(a.innovation.residual));
    a.innovation.valid=std::isfinite(a.innovation.nis)&&a.innovation.nis>=0;
  }
  a.quality=a.innovation.valid;
  // Geometric distance resolves model plate identity when yaw is uncertain.
  a.cost=a.innovation.nis+a.position_residual.squaredNorm()/.04+(plate.initialized?0.:2.);
  a.reason=!a.quality ? "nonfinite_innovation" : a.innovation.nis>continuity_.innovation_limit ? "innovation" : "accepted";
  return a;
}

bool Target::update_robust(const std::vector<std::pair<Armor,int>> &observations)
{
  continuity_diagnostics={{"updates",nlohmann::json::array()},
    {"state_before",std::vector<double>(ekf_.x.data(),ekf_.x.data()+ekf_.x.size())}};
  bool accepted=false;
  if(!observations.empty()) {
    const auto &[armor,id]=observations.front();
    auto a=assess(armor,id);
    const double gap=tools::delta_time(t_,evidence_time_);
    const bool consecutive=id==evidence_id_ && gap>0 && gap<=.075;
    if(a.quality) {
      // Bearing change is observed much more reliably than single-frame PnP
      // depth. Depth noise must not trigger a lateral maneuver or relax every
      // velocity axis at once.
      const double bearing=std::atan2(armor.xyz_in_world.y(),armor.xyz_in_world.x());
      const Eigen::Vector2d lateral(-std::sin(bearing),std::cos(bearing));
      const Eigen::Vector2d motion_innovation=consecutive ?
        (lateral*lateral.dot(a.position_residual.head<2>())).eval() : Eigen::Vector2d::Zero();
      const double lateral_threshold=std::max(.01,continuity_.bearing_noise_rad
        *armor.xyz_in_world.head<2>().norm()*1.5);
      const bool position_large=consecutive && motion_innovation.norm()>lateral_threshold;
      const double dot=motion_innovation.dot(previous_motion_innovation_);
      const double scale=motion_innovation.norm()*previous_motion_innovation_.norm();
      translation_evidence_=position_large ? (consecutive && scale>0 && dot/scale>.8 ? translation_evidence_+1 : 1) : 0;
      const double angle=a.innovation.residual[3];
      // A persistent orientation offset is not proof of angular acceleration.
      // Require coherent incremental orientation evidence instead.
      const double orientation_step=tools::limit_rad(angle-previous_angle_residual_);
      const bool angular_motion=consecutive && std::abs(orientation_step)>.01 && std::abs(orientation_step)<.15;
      rotation_evidence_=angular_motion ? (orientation_step*previous_orientation_step_>0 ? rotation_evidence_+1 : 1) : 0;
      if(translation_evidence_>=3) {
        if(translation_evidence_==3) {
          // Relax velocity certainty rather than teleporting position to data.
          for(auto &plate:plate_filters_)if(plate.initialized) {
            Eigen::Matrix<double,6,1> direction=Eigen::Matrix<double,6,1>::Zero();
            direction[1]=lateral.x();direction[3]=lateral.y();
            const double current=direction.dot(plate.P*direction);
            plate.P+=std::max(0.,4.-current)*direction*direction.transpose();
          }
        }
        translation_maneuver_=true;
      }
      if(rotation_evidence_>=3) {
        if(rotation_evidence_==3) ekf_.P(7,7)=std::max(ekf_.P(7,7),1.);
        rotation_maneuver_=true;
      }
      if(!position_large && std::abs(angle)<.15 && a.innovation.nis<continuity_.innovation_limit) ++quiet_count_;
      else quiet_count_=0;
      if(quiet_count_>=5) { translation_maneuver_=false; rotation_maneuver_=false; }
      previous_angle_residual_=angle;
      previous_orientation_step_=orientation_step;
      previous_motion_innovation_=motion_innovation;
      evidence_time_=t_; evidence_id_=id;
    } else { translation_evidence_=0;rotation_evidence_=0; }
  }
  for(const auto &[armor,id]:observations) {
    auto a=assess(armor,id);
    auto record=nlohmann::json{{"plate_id",id},{"quality",a.quality},{"reason",a.reason},
      {"reprojection_rms_px",armor.reprojection_rms_px},{"nis_prior",a.innovation.nis},
      {"position_residual_m",{a.position_residual.x(),a.position_residual.y(),a.position_residual.z()}}};
    if(a.innovation.valid) record["innovation"]=std::vector<double>(a.innovation.residual.data(),a.innovation.residual.data()+4);
    if(a.quality && a.innovation.nis<=continuity_.innovation_limit) {
      const auto before_x=ekf_.x; const auto before_P=ekf_.P;
      const auto before_plate=plate_filters_[id];
      bool ok=ekf_.correct(a.H,a.R,a.innovation);
      if(ok) {
        const Eigen::Matrix3d inverse=tools::xyz2ypd_jacobian(armor.xyz_in_world).inverse();
        const Eigen::Matrix3d R=inverse*a.R.topLeftCorner(3,3)*inverse.transpose();
        ok=plate_filters_[id].update(armor.xyz_in_world,R,std::abs(cv::contourArea(armor.points)));
      }
      if(ok && diverged()) {
        ok=false;record["reason"]="geometry_bounds";
      }
      if(!ok) {ekf_.x=before_x;ekf_.P=before_P;plate_filters_[id]=before_plate;}
      if(ok) {
        accepted=true; if(id!=0) jumped=true;
        is_switch_=id!=last_id; if(is_switch_)++switch_count_;
        last_id=id;++update_count_;
      }
      record["accepted"]=ok;
    } else record["accepted"]=false;
    continuity_diagnostics["updates"].push_back(record);
  }
  int best=-1;double best_area=0;
  for(int id=0;id<armor_num_;++id)if(plate_filters_[id].initialized && plate_filters_[id].age_s<.05) {
    double area=plate_filters_[id].area*(id==preferred_plate_?(continuity_.robust_v3?continuity_.preferred_plate_hysteresis:1.15):1.);
    if(area>best_area) {best=id;best_area=area;}
  }
  if(best>=0)preferred_plate_=best;
  sync_translation();
  continuity_diagnostics["state_after"]=std::vector<double>(ekf_.x.data(),ekf_.x.data()+ekf_.x.size());
  continuity_diagnostics["translation_maneuver"]=translation_maneuver_;
  continuity_diagnostics["rotation_maneuver"]=rotation_maneuver_;
  continuity_diagnostics["translation_evidence_frames"]=translation_evidence_;
  continuity_diagnostics["rotation_evidence_frames"]=rotation_evidence_;
  continuity_diagnostics["translation_model"]="independent_plate_cv";
  continuity_diagnostics["plates"]=nlohmann::json::array();
  for(const auto &plate:plate_filters_) {
    auto row=nlohmann::json{{"initialized",plate.initialized},{"age_s",plate.age_s}};
    if(plate.initialized) {
      row["state"]=std::vector<double>(plate.x.data(),plate.x.data()+6);
      row["covariance_column_major"]=std::vector<double>(plate.P.data(),plate.P.data()+36);
    }
    continuity_diagnostics["plates"].push_back(row);
  }
  return accepted;
}

Eigen::VectorXd Target::ekf_x() const { return ekf_.x; }

const tools::ExtendedKalmanFilter & Target::ekf() const { return ekf_; }

std::vector<Eigen::Vector4d> Target::armor_xyza_list() const
{
  std::vector<Eigen::Vector4d> _armor_xyza_list;

  for (int i = 0; i < armor_num_; i++) {
    auto angle = tools::limit_rad(ekf_.x[6] + i * 2 * CV_PI / armor_num_);
    Eigen::Vector3d xyz = h_armor_xyz(ekf_.x, i);
    if(continuity_.enabled && plate_filters_[i].initialized)xyz=plate_filters_[i].position();
    _armor_xyza_list.push_back({xyz[0], xyz[1], xyz[2], angle});
  }
  return _armor_xyza_list;
}

std::vector<Eigen::Vector3d> Target::plate_velocities() const
{
  std::vector<Eigen::Vector3d> result;
  for(const auto &plate:plate_filters_)result.push_back(plate.initialized?plate.velocity():Eigen::Vector3d::Zero());
  return result;
}

void Target::sync_translation()
{
  if(preferred_plate_<0 || !plate_filters_[preferred_plate_].initialized)return;
  const auto &plate=plate_filters_[preferred_plate_];
  const double angle=ekf_.x[6]+preferred_plate_*2*CV_PI/armor_num_;
  const bool alternate=armor_num_==4 && preferred_plate_%2;
  const double radius=ekf_.x[8]+(alternate?ekf_.x[9]:0);
  const Eigen::Vector3d center=plate.position()+Eigen::Vector3d(radius*std::cos(angle),radius*std::sin(angle),alternate?-ekf_.x[10]:0);
  for(int i=0;i<3;++i) {ekf_.x[2*i]=center[i];ekf_.x[2*i+1]=plate.velocity()[i];}
}

bool Target::diverged() const
{
  auto r_ok = ekf_.x[8] > 0.05 && ekf_.x[8] < 0.5;
  auto l_ok = ekf_.x[8] + ekf_.x[9] > 0.05 && ekf_.x[8] + ekf_.x[9] < 0.5;

  if (r_ok && l_ok) return false;

  tools::logger()->debug("[Target] r={:.3f}, l={:.3f}", ekf_.x[8], ekf_.x[9]);
  return true;
}

bool Target::convergened()
{
  if (this->name != ArmorName::outpost && update_count_ > 3 && !this->diverged()) {
    is_converged_ = true;
  }

  //前哨站特殊判断
  if (this->name == ArmorName::outpost && update_count_ > 10 && !this->diverged()) {
    is_converged_ = true;
  }

  return is_converged_;
}

// 计算出装甲板中心的坐标（考虑长短轴）
Eigen::Vector3d Target::h_armor_xyz(const Eigen::VectorXd & x, int id) const
{
  auto angle = tools::limit_rad(x[6] + id * 2 * CV_PI / armor_num_);
  auto use_l_h = (armor_num_ == 4) && (id == 1 || id == 3);

  auto r = (use_l_h) ? x[8] + x[9] : x[8];
  auto armor_x = x[0] - r * std::cos(angle);
  auto armor_y = x[2] - r * std::sin(angle);
  auto armor_z = (use_l_h) ? x[4] + x[10] : x[4];

  return {armor_x, armor_y, armor_z};
}

Eigen::MatrixXd Target::h_jacobian(const Eigen::VectorXd & x, int id) const
{
  auto angle = tools::limit_rad(x[6] + id * 2 * CV_PI / armor_num_);
  auto use_l_h = (armor_num_ == 4) && (id == 1 || id == 3);

  auto r = (use_l_h) ? x[8] + x[9] : x[8];
  auto dx_da = r * std::sin(angle);
  auto dy_da = -r * std::cos(angle);

  auto dx_dr = -std::cos(angle);
  auto dy_dr = -std::sin(angle);
  auto dx_dl = (use_l_h) ? -std::cos(angle) : 0.0;
  auto dy_dl = (use_l_h) ? -std::sin(angle) : 0.0;

  auto dz_dh = (use_l_h) ? 1.0 : 0.0;

  // clang-format off
  Eigen::MatrixXd H_armor_xyza{
    {1, 0, 0, 0, 0, 0, dx_da, 0, dx_dr, dx_dl,     0},
    {0, 0, 1, 0, 0, 0, dy_da, 0, dy_dr, dy_dl,     0},
    {0, 0, 0, 0, 1, 0,     0, 0,     0,     0, dz_dh},
    {0, 0, 0, 0, 0, 0,     1, 0,     0,     0,     0}
  };
  // clang-format on

  Eigen::VectorXd armor_xyz = h_armor_xyz(x, id);
  Eigen::MatrixXd H_armor_ypd = tools::xyz2ypd_jacobian(armor_xyz);
  // clang-format off
  Eigen::MatrixXd H_armor_ypda{
    {H_armor_ypd(0, 0), H_armor_ypd(0, 1), H_armor_ypd(0, 2), 0},
    {H_armor_ypd(1, 0), H_armor_ypd(1, 1), H_armor_ypd(1, 2), 0},
    {H_armor_ypd(2, 0), H_armor_ypd(2, 1), H_armor_ypd(2, 2), 0},
    {                0,                 0,                 0, 1}
  };
  // clang-format on

  return H_armor_ypda * H_armor_xyza;
}

bool Target::checkinit() { return isinit; }

}  // namespace auto_aim
