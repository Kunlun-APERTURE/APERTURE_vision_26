#include "yolov5.hpp"

#include <fmt/chrono.h>
#include <yaml-cpp/yaml.h>

#include <filesystem>
#include <algorithm>

#include "tools/img_tools.hpp"
#include "tools/logger.hpp"

namespace auto_aim
{
YOLOV5::YOLOV5(const std::string & config_path, bool debug)
: debug_(debug), detector_(config_path, false)
{
  auto yaml = YAML::LoadFile(config_path);

  model_path_ = yaml["yolov5_model_path"].as<std::string>();
  device_ = yaml["device"].as<std::string>();
  binary_threshold_ = yaml["threshold"].as<double>();
  min_confidence_ = yaml["min_confidence"].as<double>();
  const auto profile=yaml["algorithm_profile"] ? yaml["algorithm_profile"].as<std::string>() : "legacy";
  allow_track_candidates_=profile=="tracking_v3" || profile=="tracking_fire_v3";
  multi_scale_search_=allow_track_candidates_ && (!yaml["robustness_v3"] || !yaml["robustness_v3"]["multi_scale_search"] || yaml["robustness_v3"]["multi_scale_search"].as<bool>());
  enemy_color_=yaml["enemy_color"].as<std::string>()=="red" ? Color::red : Color::blue;
  int x = 0, y = 0, width = 0, height = 0;
  x = yaml["roi"]["x"].as<int>();
  y = yaml["roi"]["y"].as<int>();
  width = yaml["roi"]["width"].as<int>();
  height = yaml["roi"]["height"].as<int>();
  use_roi_ = yaml["use_roi"].as<bool>();
  use_traditional_ = yaml["use_traditional"].as<bool>();
  roi_ = cv::Rect(x, y, width, height);
  offset_ = cv::Point2f(x, y);

  save_path_ = "imgs";
  std::filesystem::create_directory(save_path_);
  auto model = core_.read_model(model_path_);
  ov::preprocess::PrePostProcessor ppp(model);
  auto & input = ppp.input();

  input.tensor()
    .set_element_type(ov::element::u8)
    .set_shape({1, 640, 640, 3})
    .set_layout("NHWC")
    .set_color_format(ov::preprocess::ColorFormat::BGR);

  input.model().set_layout("NCHW");

  input.preprocess()
    .convert_element_type(ov::element::f32)
    .convert_color(ov::preprocess::ColorFormat::RGB)
    .scale(255.0);

  // TODO: ov::hint::performance_mode(ov::hint::PerformanceMode::LATENCY)
  model = ppp.build();
  compiled_model_ = core_.compile_model(
    model, device_, ov::hint::performance_mode(ov::hint::PerformanceMode::LATENCY));
}

std::list<Armor> YOLOV5::detect(const cv::Mat & raw_img, int frame_count)
{
  diagnostic_=nullptr;summary_=nullptr;
  if(diagnostic_enabled_) diagnostic_={{"schema_version",1},{"candidates",nlohmann::json::array()}};
  if (raw_img.empty()) {
    tools::logger()->warn("Empty img!, camera drop!");
    return std::list<Armor>();
  }

  cv::Mat bgr_img;
  if (use_roi_) {
    if (roi_.width == -1) {  // -1 表示该维度不裁切
      roi_.width = raw_img.cols;
    }
    if (roi_.height == -1) {  // -1 表示该维度不裁切
      roi_.height = raw_img.rows;
    }
    bgr_img = raw_img(roi_);
  } else {
    bgr_img = raw_img;
  }

  auto x_scale = static_cast<double>(640) / bgr_img.rows;
  auto y_scale = static_cast<double>(640) / bgr_img.cols;
  auto scale = std::min(x_scale, y_scale);
  auto h = static_cast<int>(bgr_img.rows * scale);
  auto w = static_cast<int>(bgr_img.cols * scale);

  // preproces
  auto input = cv::Mat(640, 640, CV_8UC3, cv::Scalar(0, 0, 0));
  auto roi = cv::Rect(0, 0, w, h);
  cv::resize(bgr_img, input(roi), {w, h});
  ov::Tensor input_tensor(ov::element::u8, {1, 640, 640, 3}, input.data);

  // infer
  auto infer_request = compiled_model_.create_infer_request();
  infer_request.set_input_tensor(input_tensor);
  infer_request.infer();

  // postprocess
  auto output_tensor = infer_request.get_output_tensor();
  auto output_shape = output_tensor.get_shape();
  cv::Mat output(output_shape[1], output_shape[2], CV_32F, output_tensor.data());

  auto armors=parse(scale,output,raw_img,frame_count);
  if(multi_scale_search_)summary_={{"passes",1},{"input_scale",scale},{"tile_roi",nullptr},{"full_output_count",armors.size()}};
  const auto strong=[&](const std::list<Armor> &values) {
    return std::any_of(values.begin(),values.end(),[&](const Armor &a){return a.color==enemy_color_ && a.confidence>min_confidence_;});
  };
  // Full-frame resizing loses small-object pixels. A bounded second inference
  // scans image tiles on misses, then reuses the last successful image region.
  // No tracker truth, target map position, lower threshold or extra hold enters it.
  const bool strong_full=std::any_of(armors.begin(),armors.end(),[&](const Armor &a){return a.color==enemy_color_ && a.confidence>=.95;});
  const bool have_cached=cached_roi_.area()>0 && cached_failures_<2;
  if(multi_scale_search_ && !use_roi_ && !searching_tile_ && (search_index_==0 || have_cached || !strong_full)) {
    const int width=std::min(640,raw_img.cols),height=std::min(640,raw_img.rows);
    if(width<raw_img.cols || height<raw_img.rows) {
      std::vector<cv::Rect> tiles;
      const int xs[]={ (raw_img.cols-width)/2,0,raw_img.cols-width };
      const int ys[]={ (raw_img.rows-height)/2,0,raw_img.rows-height };
      for(int y:ys)for(int x:xs) {
        const cv::Rect tile(x,y,width,height);
        if(std::find(tiles.begin(),tiles.end(),tile)==tiles.end())tiles.push_back(tile);
      }
      const bool cached=cached_roi_.area()>0 && cached_roi_.x+cached_roi_.width<=raw_img.cols && cached_roi_.y+cached_roi_.height<=raw_img.rows && cached_failures_<2;
      const auto chosen=cached?cached_roi_:tiles[search_index_++%tiles.size()];
      const auto saved_roi=roi_;const auto saved_offset=offset_;const auto full_diagnostic=diagnostic_;const auto full_summary=summary_;
      searching_tile_=true;use_roi_=true;roi_=chosen;offset_=cv::Point2f(chosen.x,chosen.y);
      std::list<Armor> extra;
      try {extra=detect(raw_img,frame_count);}
      catch(...) {searching_tile_=false;use_roi_=false;roi_=saved_roi;offset_=saved_offset;throw;}
      const auto tile_diagnostic=diagnostic_;
      searching_tile_=false;use_roi_=false;roi_=saved_roi;offset_=saved_offset;
      if(strong(extra)) {cached_roi_=chosen;cached_failures_=0;} else if(cached)++cached_failures_;
      // For small objects, use native-resolution keypoints from a credible
      // tile observation. An aliased full-frame confidence alone must not
      // switch the measurement scale from one frame to the next.
      for(const auto &fine:extra)if(fine.confidence>min_confidence_) {
        const auto box=cv::boundingRect(fine.points);
        if(box.width<=50 && box.height<=40)armors.remove_if([&](const Armor &coarse) {
          const auto other=cv::boundingRect(coarse.points);const double intersection=(box&other).area();
          return intersection/std::max(1.,double(box.area()+other.area())-intersection)>.3;
        });
      }
      // Resolve duplicate physical observations across scales before association.
      armors.splice(armors.end(),extra);
      armors.sort([](const Armor &a,const Armor &b){return a.confidence>b.confidence;});
      std::list<Armor> merged;
      for(const auto &a:armors) {
        const auto box=cv::boundingRect(a.points);bool duplicate=false;
        for(const auto &b:merged) {
          const auto other=cv::boundingRect(b.points);
          const double intersection=(box&other).area();
          if(intersection/std::max(1.,double(box.area()+other.area())-intersection)>.3) {duplicate=true;break;}
        }
        if(!duplicate)merged.push_back(a);
      }
      armors=std::move(merged);diagnostic_=full_diagnostic;summary_=full_summary;
      summary_["passes"]=2;summary_["tile_roi"]={chosen.x,chosen.y,chosen.width,chosen.height};
      summary_["cached_tile"]=cached;summary_["output_count"]=armors.size();
      if(diagnostic_enabled_) {
        diagnostic_["tile_roi"]={chosen.x,chosen.y,chosen.width,chosen.height};
        diagnostic_["tile_pass"]=tile_diagnostic;diagnostic_["merged_output_count"]=armors.size();
      }
    }
  }
  return armors;
}

std::list<Armor> YOLOV5::parse(
  double scale, cv::Mat & output, const cv::Mat & bgr_img, int frame_count)
{
  // for each row: xywh + classess
  std::vector<int> color_ids, num_ids, rows;
  auto points_json=[](const std::vector<cv::Point2f> &points) {
    auto value=nlohmann::json::array(); for(const auto &p:points)value.push_back({p.x,p.y}); return value;
  };
  std::vector<float> confidences;
  std::vector<cv::Rect> boxes;
  std::vector<std::vector<cv::Point2f>> armors_key_points;
  for (int r = 0; r < output.rows; r++) {
    double score = output.at<float>(r, 8);
    score = sigmoid(score);

    if(diagnostic_enabled_ && score>=.05) {
      auto scores=nlohmann::json::array();for(int k=9;k<22;++k)scores.push_back(output.at<float>(r,k));
      auto points=nlohmann::json::array();for(int k=0;k<8;k+=2)points.push_back({output.at<float>(r,k)/scale+(use_roi_?offset_.x:0),output.at<float>(r,k+1)/scale+(use_roi_?offset_.y:0)});
      diagnostic_["candidates"].push_back({{"candidate_id",r},{"confidence",score},{"raw_color_and_class_logits",scores},
        {"raw_keypoints",points},{"reason",score<score_threshold_?"score_threshold":"nms"}});
    }
    if (score < score_threshold_) continue;

    std::vector<cv::Point2f> armor_key_points;

    //颜色和类别独热向量
    cv::Mat color_scores = output.row(r).colRange(9, 13);     //color
    cv::Mat classes_scores = output.row(r).colRange(13, 22);  //num
    cv::Point class_id, color_id;
    int _class_id, _color_id;
    double score_color, score_num;
    cv::minMaxLoc(classes_scores, NULL, &score_num, NULL, &class_id);
    cv::minMaxLoc(color_scores, NULL, &score_color, NULL, &color_id);
    _class_id = class_id.x;
    _color_id = color_id.x;

    armor_key_points.push_back(
      cv::Point2f(output.at<float>(r, 0) / scale, output.at<float>(r, 1) / scale));
    armor_key_points.push_back(
      cv::Point2f(output.at<float>(r, 6) / scale, output.at<float>(r, 7) / scale));
    armor_key_points.push_back(
      cv::Point2f(output.at<float>(r, 4) / scale, output.at<float>(r, 5) / scale));
    armor_key_points.push_back(
      cv::Point2f(output.at<float>(r, 2) / scale, output.at<float>(r, 3) / scale));

    float min_x = armor_key_points[0].x;
    float max_x = armor_key_points[0].x;
    float min_y = armor_key_points[0].y;
    float max_y = armor_key_points[0].y;

    for (int i = 1; i < armor_key_points.size(); i++) {
      if (armor_key_points[i].x < min_x) min_x = armor_key_points[i].x;
      if (armor_key_points[i].x > max_x) max_x = armor_key_points[i].x;
      if (armor_key_points[i].y < min_y) min_y = armor_key_points[i].y;
      if (armor_key_points[i].y > max_y) max_y = armor_key_points[i].y;
    }

    cv::Rect rect(min_x, min_y, max_x - min_x, max_y - min_y);

    rows.push_back(r);
    color_ids.emplace_back(_color_id);
    num_ids.emplace_back(_class_id);
    boxes.emplace_back(rect);
    confidences.emplace_back(score);
    armors_key_points.emplace_back(armor_key_points);
  }

  std::vector<int> indices;
  cv::dnn::NMSBoxes(boxes, confidences, score_threshold_, nms_threshold_, indices);

  std::list<Armor> armors;
  tmp_img_ = bgr_img;
  for (const auto & i : indices) {
    Armor armor = use_roi_ ? Armor(color_ids[i],num_ids[i],confidences[i],boxes[i],armors_key_points[i],offset_)
      : Armor(color_ids[i],num_ids[i],confidences[i],boxes[i],armors_key_points[i]);
    nlohmann::json *trace=nullptr;
    if(diagnostic_enabled_) for(auto &c:diagnostic_["candidates"])if(c["candidate_id"]==rows[i]) {trace=&c;break;}
    if(trace) {
      (*trace)["color"]=COLORS.at(armor.color);(*trace)["name"]=ARMOR_NAMES.at(armor.name);
      (*trace)["type"]=ARMOR_TYPES.at(armor.type);(*trace)["corners_before_refine"]=points_json(armor.points);
    }
    if (!check_name(armor) && !(allow_track_candidates_ && armor.name!=ArmorName::not_armor && armor.confidence>=score_threshold_)) {
      if(trace)(*trace)["reason"]=armor.name==ArmorName::not_armor?"not_armor":"min_confidence";
      continue;
    }
    if (!check_type(armor)) { if(trace)(*trace)["reason"]="type_class"; continue; }
    if (use_traditional_) {
      const bool refined=detector_.detect(armor,bgr_img);
      if(trace) { (*trace)["refined"]=refined; (*trace)["refinement_reason"]=detector_.refinement_reason; }
    }
    armor.center_norm=get_center_norm(bgr_img,armor.center);
    if(trace) {(*trace)["reason"]="accepted";(*trace)["corners"]=points_json(armor.points);}
    armors.push_back(armor);
  }
  if(diagnostic_enabled_) {
    diagnostic_["output_count"]=armors.size();diagnostic_["network_rows"]=output.rows;
    diagnostic_["log_score_floor"]=.05;diagnostic_["score_threshold"]=score_threshold_;
    diagnostic_["min_confidence"]=min_confidence_;
  }

  if (debug_) draw_detections(bgr_img, armors, frame_count);

  return armors;
}

bool YOLOV5::check_name(const Armor & armor) const
{
  auto name_ok = armor.name != ArmorName::not_armor;
  auto confidence_ok = armor.confidence > min_confidence_;

  // 保存不确定的图案，用于神经网络的迭代
  // if (name_ok && !confidence_ok) save(armor);

  return name_ok && confidence_ok;
}

bool YOLOV5::check_type(const Armor & armor) const
{
  auto name_ok = (armor.type == ArmorType::small)
                   ? (armor.name != ArmorName::one && armor.name != ArmorName::base)
                   : (armor.name != ArmorName::two && armor.name != ArmorName::sentry &&
                      armor.name != ArmorName::outpost);

  // 保存异常的图案，用于神经网络的迭代
  // if (!name_ok) save(armor);

  return name_ok;
}

cv::Point2f YOLOV5::get_center_norm(const cv::Mat & bgr_img, const cv::Point2f & center) const
{
  auto h = bgr_img.rows;
  auto w = bgr_img.cols;
  return {center.x / w, center.y / h};
}

void YOLOV5::draw_detections(
  const cv::Mat & img, const std::list<Armor> & armors, int frame_count) const
{
  auto detection = img.clone();
  tools::draw_text(detection, fmt::format("[{}]", frame_count), {10, 30}, {255, 255, 255});
  for (const auto & armor : armors) {
    auto info = fmt::format(
      "{:.2f} {} {} {}", armor.confidence, COLORS[armor.color], ARMOR_NAMES[armor.name],
      ARMOR_TYPES[armor.type]);
    tools::draw_points(detection, armor.points, {0, 255, 0});
    tools::draw_text(detection, info, armor.center, {0, 255, 0});
  }

  if (use_roi_) {
    cv::Scalar green(0, 255, 0);
    cv::rectangle(detection, roi_, green, 2);
  }
  cv::resize(detection, detection, {}, 0.5, 0.5);  // 显示时缩小图片尺寸
  cv::imshow("detection", detection);
}

void YOLOV5::save(const Armor & armor) const
{
  auto file_name = fmt::format("{:%Y-%m-%d_%H-%M-%S}", std::chrono::system_clock::now());
  auto img_path = fmt::format("{}/{}_{}.jpg", save_path_, armor.name, file_name);
  cv::imwrite(img_path, tmp_img_);
}

double YOLOV5::sigmoid(double x)
{
  if (x > 0)
    return 1.0 / (1.0 + exp(-x));
  else
    return exp(x) / (1.0 + exp(x));
}

std::list<Armor> YOLOV5::postprocess(
  double scale, cv::Mat & output, const cv::Mat & bgr_img, int frame_count)
{
  return parse(scale, output, bgr_img, frame_count);
}

}  // namespace auto_aim