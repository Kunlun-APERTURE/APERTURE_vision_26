#ifndef AUTO_AIM__SHOOTER_HPP
#define AUTO_AIM__SHOOTER_HPP

#include <string>

#include "io/command.hpp"
#include "tasks/auto_aim/aimer.hpp"

namespace auto_aim
{
class Shooter
{
public:
  Shooter(const std::string & config_path);

  bool shoot(
    const io::Command & command, const auto_aim::Aimer & aimer,
    const std::list<auto_aim::Target> & targets, const Eigen::Vector3d & gimbal_pos);
  struct FireContext {
    double yaw=0,elevation=0,pose_age_s=1;
    double target_half_width_rad=-1; // negative: caller did not provide geometry
    std::chrono::steady_clock::time_point capture_time{},now{};
    bool tracking=false,measurement_fresh=false;
    unsigned generation=0;
    int plate_id=-1;
  };
  bool shoot_current(const io::Command &command,const FireContext &context);
  nlohmann::json diagnostics;

private:
  io::Command last_command_;
  double judge_distance_;
  double first_tolerance_;
  double second_tolerance_;
  bool auto_fire_;
  ContinuityConfig continuity_;
  bool previous_valid_=false,previous_aligned_=false,previous_command_valid_=false,previous_good_=false;
  std::chrono::steady_clock::time_point last_good_time_{};
  int stable_frames_=0,previous_plate_=-1;
  double stable_time_s_=0;
  unsigned previous_generation_=0;
  double previous_yaw_rate_=0,previous_pitch_rate_=0;
  std::chrono::steady_clock::time_point previous_time_{};
};
}  // namespace auto_aim

#endif  // AUTO_AIM__SHOOTER_HPP
