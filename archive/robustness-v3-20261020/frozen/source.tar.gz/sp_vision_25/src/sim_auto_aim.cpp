// Simulator-only transport; no ROS, camera, CAN or serial objects are created.
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <map>
#include <thread>
#include <nlohmann/json.hpp>
#include <opencv2/opencv.hpp>
#include <yaml-cpp/yaml.h>

#include "tasks/auto_aim/aimer.hpp"
#include "tasks/auto_aim/shooter.hpp"
#include "tools/math_tools.hpp"
#include "tools/logger.hpp"
#include "tasks/auto_aim/solver.hpp"
#include "tasks/auto_aim/tracker.hpp"
#include "tasks/auto_aim/yolo.hpp"

using Json = nlohmann::json;
using Steady = std::chrono::steady_clock;
static volatile std::sig_atomic_t stopping = 0;
static void stop(int) { stopping = 1; }

struct Connection {
  int fd = -1;
  ~Connection() { if (fd >= 0) ::close(fd); }
  bool transfer(void * data, size_t size, bool write) {
    auto * p = static_cast<char *>(data);
    while (size && !stopping) {
      auto count = write ? ::send(fd, p, size, MSG_NOSIGNAL) : ::recv(fd, p, size, 0);
      if (count < 0 && errno == EINTR) continue;
      if (count <= 0) return false;
      p += count;
      size -= count;
    }
    return size == 0;
  }
  bool send(const Json & header) {
    auto body = header.dump();
    uint32_t lengths[] = {htonl(static_cast<uint32_t>(body.size())), 0};
    return transfer(lengths, sizeof(lengths), true) && transfer(body.data(), body.size(), true);
  }
  bool receive(Json & header, std::vector<uchar> & jpeg) {
    uint32_t lengths[2];
    if (!transfer(lengths, sizeof(lengths), false)) return false;
    auto h = ntohl(lengths[0]), b = ntohl(lengths[1]);
    if (h == 0 || h > 65536 || b > 16 * 1024 * 1024) return false;
    std::string body(h, '\0');
    jpeg.resize(b);
    if (!transfer(body.data(), h, false) || !transfer(jpeg.data(), b, false)) return false;
    header = Json::parse(body);
    return header.value("version", 0) == 1;
  }
};

struct Pipeline {
  auto_aim::Solver solver;
  auto_aim::Tracker tracker;
  auto_aim::Aimer aimer;
  auto_aim::Shooter shooter;
  explicit Pipeline(const std::string & config) : solver(config), tracker(config, solver), aimer(config), shooter(config) {}
};

static void calibration_file(const YAML::Node & base, const Json & calibration, const std::string & path, bool fire) {
  auto yaml = YAML::Clone(base);
  yaml["camera_matrix"] = calibration.at("k").get<std::vector<double>>();
  yaml["distort_coeffs"] = calibration.at("d").get<std::vector<double>>();
  yaml["R_camera2gimbal"] = calibration.at("r_camera2gimbal").get<std::vector<double>>();
  yaml["t_camera2gimbal"] = calibration.at("t_camera2gimbal").get<std::vector<double>>();
  yaml["R_gimbal2imubody"] = std::vector<double>{1,0,0,0,1,0,0,0,1};
  yaml["yaw_offset"] = 0.0;
  yaml["pitch_offset"] = 0.0;
  yaml["auto_fire"] = fire;
  std::ofstream out(path);
  out << yaml;
  if (!out.good()) throw std::runtime_error("Cannot write runtime calibration");
}

static void attach_diagnostics(Json &result,Pipeline &pipeline,const std::list<auto_aim::Target> &targets) {
  result["diagnostics_version"]=2;
  result["continuity"]=pipeline.tracker.diagnostics();
  result["fire_check"]=pipeline.shooter.diagnostics;
  result["selected_plate_id"]=pipeline.aimer.selected_plate_id;
  result["prediction_horizon_s"]=pipeline.aimer.prediction_horizon_s;
  if(!targets.empty()) {
    auto x=targets.front().ekf_x();
    result["filter_state"]=std::vector<double>(x.data(),x.data()+x.size());
    result["track_generation"]=targets.front().generation;
    const auto velocities=targets.front().plate_velocities();
    if(!velocities.empty()) {
      result["prediction_model"]="plate_cv";
      result["plate_velocities"]=Json::array();
      for(const auto &v:velocities)result["plate_velocities"].push_back({v[0],v[1],v[2]});
      if(result.contains("track_estimate") && !result["track_estimate"].is_null()) {
        result["track_estimate"]["prediction_model"]="plate_cv";
        result["track_estimate"]["plate_velocities"]=result["plate_velocities"];
        result["track_estimate"]["selected_plate_id"]=pipeline.aimer.selected_plate_id;
      }
    }
  }
}

static int replay(const std::string &input,const std::string &output,const std::string &runtime,
  const YAML::Node &base,const std::string &raw_folder="",bool detector_diagnostics=false) {
  tools::logger()->set_level(spdlog::level::off);
  std::ifstream source(input);std::ofstream dest(output);
  if(!source || !dest)throw std::runtime_error("Cannot open replay input/output");
  std::unique_ptr<Pipeline> pipeline;std::string session,calibration_id,line;
  std::unique_ptr<auto_aim::YOLO> yolo;
  std::map<int64_t,std::pair<int64_t,int64_t>> jpeg_index;
  std::ifstream jpegs;
  if(!raw_folder.empty()) {
    const auto detector_config=runtime+".detector.yaml";
    {std::ofstream config_out(detector_config);config_out<<base;}
    yolo=std::make_unique<auto_aim::YOLO>(detector_config,false);
    yolo->enable_diagnostics(detector_diagnostics);
    std::ifstream index(std::filesystem::path(raw_folder)/"frames.jsonl");std::string row;
    while(std::getline(index,row)) {const auto j=Json::parse(row);jpeg_index[j.at("stamp_ns").get<int64_t>()]={j.at("jpeg_offset"),j.at("jpeg_bytes")};}
    jpegs.open(std::filesystem::path(raw_folder)/"input.mjpg",std::ios::binary);
    if(!index.eof() || !jpegs)throw std::runtime_error("Cannot read original image index/payload");
  }
  int64_t previous=0;
  const auto origin=Steady::time_point(std::chrono::seconds(100));
  int64_t anchor=0;
  while(std::getline(source,line)) {
    const auto packet=Json::parse(line);
    if(packet.value("kind","")!="observation")continue;
    const auto &observation=packet.at("data");const auto &frame=observation.at("frame");
    const auto &calibration=frame.at("calibration");
    const int64_t stamp=frame.at("stamp_ns");if(!anchor)anchor=stamp;
    auto t=origin+std::chrono::nanoseconds(stamp-anchor);
    const auto next_session=frame.at("session").get<std::string>();
    const auto next_calibration=calibration.at("id").get<std::string>();
    if(!pipeline || session!=next_session || calibration_id!=next_calibration || stamp<=previous
        || (previous && stamp-previous>250000000)) {
      calibration_file(base,calibration,runtime,true);pipeline=std::make_unique<Pipeline>(runtime);
      session=next_session;calibration_id=next_calibration;
    }
    previous=stamp;
    const auto q=frame.at("q_gimbal2world").get<std::vector<double>>();
    pipeline->solver.set_R_gimbal2world(Eigen::Quaterniond(q[3],q[0],q[1],q[2]).normalized());
    const auto rotation=calibration.at("r_camera2gimbal").get<std::vector<double>>();
    const auto translation=calibration.at("t_camera2gimbal").get<std::vector<double>>();
    pipeline->solver.set_camera2gimbal(Eigen::Map<const Eigen::Matrix<double,3,3,Eigen::RowMajor>>(rotation.data()),
      Eigen::Map<const Eigen::Vector3d>(translation.data()));
    std::list<auto_aim::Armor> armors;
    for(const auto &d:observation.at("result").value("observations",Json::array())) {
      std::vector<cv::Point2f> corners;
      for(const auto &point:d.at("corners"))corners.emplace_back(point[0].get<float>(),point[1].get<float>());
      const auto name=d.at("name").get<std::string>();const auto color=d.at("color").get<std::string>();
      const int name_id=std::find(auto_aim::ARMOR_NAMES.begin(),auto_aim::ARMOR_NAMES.end(),name)-auto_aim::ARMOR_NAMES.begin();
      const int color_id=std::find(auto_aim::COLORS.begin(),auto_aim::COLORS.end(),color)-auto_aim::COLORS.begin();
      if(name_id>=int(auto_aim::ARMOR_NAMES.size())||color_id>=int(auto_aim::COLORS.size())||corners.size()!=4)continue;
      int class_id=-1;
      for(size_t i=0;i<auto_aim::armor_properties.size();++i) {
        const auto &[c,n,type]=auto_aim::armor_properties[i];
        if(c==color_id && n==name_id && auto_aim::ARMOR_TYPES[type]==d.at("type")) {class_id=i;break;}
      }
      if(class_id<0)continue;
      armors.emplace_back(class_id,d.value("confidence",1.),cv::boundingRect(corners),corners);
    }
    bool raw_replayed=false;
    Json raw_observations=Json::array();
    if(yolo && jpeg_index.count(stamp)) {
      const auto [offset,size]=jpeg_index.at(stamp);
      std::vector<uchar> bytes(size);jpegs.seekg(offset);jpegs.read(reinterpret_cast<char*>(bytes.data()),size);
      if(!jpegs)throw std::runtime_error("Incomplete JPEG payload");
      auto img=cv::imdecode(bytes,cv::IMREAD_COLOR);
      if(img.empty())throw std::runtime_error("Invalid JPEG");
      armors=yolo->detect(img,int(frame.at("seq").get<uint64_t>()%1000000000));raw_replayed=true;
      for(const auto &a:armors) {
        Json corners=Json::array();for(const auto &p:a.points)corners.push_back({p.x,p.y});
        raw_observations.push_back({{"corners",corners},{"confidence",a.confidence},{"name",auto_aim::ARMOR_NAMES.at(a.name)},
          {"color",auto_aim::COLORS.at(a.color)},{"type",auto_aim::ARMOR_TYPES.at(a.type)}});
      }
    }
    auto targets=pipeline->tracker.track(armors,t);
    const auto muzzle=frame.at("muzzle_position_map").get<std::vector<double>>();
    const auto gimbal=frame.at("gimbal_position_map").get<std::vector<double>>();
    pipeline->aimer.set_muzzle_position(Eigen::Map<const Eigen::Vector3d>(muzzle.data())-Eigen::Map<const Eigen::Vector3d>(gimbal.data()));
    const double age=(observation.at("receipt_ns").get<int64_t>()-stamp)*1e-9;
    pipeline->aimer.set_processing_age(age);
    const auto command=pipeline->aimer.aim(targets,t,frame.at("bullet_speed"),true);
    Json result={{"stamp_ns",stamp},{"seq",frame.at("seq")},{"valid",command.control},
      {"yaw",command.yaw},{"pitch",command.pitch},{"tracker",pipeline->tracker.state()}};
    if(command.control) {
      const auto point=pipeline->aimer.debug_aim_point.xyza;
      result["aim_point"]={point[0],point[1],point[2]};
    } else result["aim_point"]=nullptr;
    attach_diagnostics(result,*pipeline,targets);
    if(yolo) {result["raw_replayed"]=raw_replayed;result["observations"]=raw_observations;
      result["detector"]=raw_replayed?yolo->diagnostics():Json(nullptr);
      if(base["algorithm_profile"].as<std::string>()=="tracking_v3" || base["algorithm_profile"].as<std::string>()=="tracking_fire_v3")result["detector_summary"]=raw_replayed?yolo->summary():Json(nullptr);}
    dest<<result.dump()<<'\n';
  }
  return 0;
}

int main(int argc, char ** argv) {
  const std::string keys =
    "{help h | | Show arguments}"
    "{port |18726| Loopback bridge port}"
    "{config |configs/simulator.yaml| Simulator configuration}"
    "{runtime |build/sim/calibration.yaml| Generated calibration}"
    "{view |false| Show annotated preview}"
    "{fire |off| off or auto: simulator-only firing advice}"
    "{algorithm-profile |legacy| legacy, tracking_v2, tracking_fire_v2, tracking_v3, tracking_fire_v3}"
    "{translation-variance |-1| Offline parameter selection override}"
    "{rotation-variance |-1| Offline parameter selection override}"
    "{replay | | Read recorded observations without a simulator}"
    "{replay-output |/dev/stdout| Offline result JSONL}"
    "{raw-replay | | Folder containing input.mjpg and frames.jsonl}"
    "{detector-diagnostics |false| Record detector candidates during offline replay}"
    "{aim-origin |muzzle| muzzle or gimbal: calibrated origin or legacy comparison}";
  cv::CommandLineParser cli(argc, argv, keys);
  if (cli.has("help")) { cli.printMessage(); return 0; }
  const int port = cli.get<int>("port");
  const bool view = cli.get<bool>("view");
  const auto fire = cli.get<std::string>("fire");
  const auto aim_origin = cli.get<std::string>("aim-origin");
  const auto config = cli.get<std::string>("config");
  const auto runtime = cli.get<std::string>("runtime");
  const auto profile=cli.get<std::string>("algorithm-profile");
  if (!cli.check() || port < 1 || port > 65535 || (fire != "off" && fire != "auto")) return 2;
  if (aim_origin != "muzzle" && aim_origin != "gimbal") return 2;
  if(profile!="legacy" && profile!="tracking_v2" && profile!="tracking_fire_v2" && profile!="tracking_v3" && profile!="tracking_fire_v3")return 2;
  std::signal(SIGINT, stop);
  std::signal(SIGTERM, stop);
  // SIGPIPE is suppressed per send; signals interrupt bounded socket reads.
  std::filesystem::create_directories(std::filesystem::path(runtime).parent_path());
  try {
    auto base = YAML::LoadFile(config);
    base["algorithm_profile"]=profile;
    base["replay_config_path"]=config;
    for(const auto key:{"translation-variance","rotation-variance"}) {
      const double value=cli.get<double>(key);
      if(value>0)base["continuity_v2"][std::string(key)=="translation-variance"?"translation_variance":"rotation_variance"]=value;
    }
    if(!cli.get<std::string>("replay").empty())return replay(cli.get<std::string>("replay"),cli.get<std::string>("replay-output"),runtime,base,cli.get<std::string>("raw-replay"),cli.get<bool>("detector-diagnostics"));
    const auto detector_config=runtime+".detector.yaml";
    {std::ofstream config_out(detector_config);config_out<<base;}
    auto_aim::YOLO yolo(detector_config, false);
    while (!stopping) {
      try {
        Connection socket;
        socket.fd = ::socket(AF_INET, SOCK_STREAM, 0);
        if (socket.fd < 0) throw std::runtime_error("socket failed");
        int no_delay = 1;
        setsockopt(socket.fd, IPPROTO_TCP, TCP_NODELAY, &no_delay, sizeof(no_delay));
        timeval timeout{2, 0};
        setsockopt(socket.fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        setsockopt(socket.fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
        sockaddr_in address{};
        address.sin_family = AF_INET;
        address.sin_port = htons(port);
        address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (::connect(socket.fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)) != 0)
          throw std::runtime_error("Bridge unavailable; reconnecting");
        std::unique_ptr<Pipeline> pipeline;
        std::string calibration_id, session;
        int64_t previous_stamp = 0;
        // Both processes share the host clock. Map capture wall time into the
        // algorithm's steady clock without replacing capture time with arrival.
        auto steady_anchor = Steady::now();
        auto wall_anchor = std::chrono::system_clock::now();
        auto wall_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(wall_anchor.time_since_epoch()).count();
        auto last_report = Steady::now();
        int processed = 0;
        while (!stopping) {
          if (!socket.send({{"version",1},{"type","next"}})) break;
          Json frame;
          std::vector<uchar> jpeg;
          if (!socket.receive(frame, jpeg)) break;
          if (frame.value("type", "") == "wait") continue;
          if (frame.value("type", "") != "frame") throw std::runtime_error("Unexpected bridge message");
          auto stamp = frame.at("stamp_ns").get<int64_t>();
          auto next_session = frame.at("session").get<std::string>();
          const auto & calibration = frame.at("calibration");
          auto next_id = calibration.at("id").get<std::string>();
          auto timestamp = steady_anchor + std::chrono::nanoseconds(stamp - wall_ns);
          double age_ms = std::chrono::duration<double,std::milli>(Steady::now() - timestamp).count();
          Json result{{"version",1},{"type","command"},{"session",next_session},
            {"seq",frame.at("seq")},{"stamp_ns",stamp},{"valid",false},
            {"yaw",0.0},{"pitch",0.0},{"distance",-1.0},{"fire_advice",false}};
          // Re-anchor after a wall-clock adjustment; never advance an EKF with
          // a negative or stale dt. The next frame starts a clean tracker.
          auto wall_now = std::chrono::system_clock::now();
          auto drift = (wall_now - wall_anchor) - (Steady::now() - steady_anchor);
          if (std::abs(std::chrono::duration<double,std::milli>(drift).count()) > 50) {
            pipeline.reset(); previous_stamp = 0;
            steady_anchor = Steady::now(); wall_anchor = std::chrono::system_clock::now();
            wall_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(wall_anchor.time_since_epoch()).count();
            socket.send(result); continue;
          }
          if (age_ms < -10 || age_ms > 250 || stamp <= previous_stamp) {
            pipeline.reset(); previous_stamp = 0; socket.send(result); continue;
          }
          if (!pipeline || next_id != calibration_id || next_session != session ||
              (previous_stamp && stamp - previous_stamp > (profile=="legacy"?100000000:250000000))) {
            calibration_file(base, calibration, runtime, fire == "auto");
            pipeline = std::make_unique<Pipeline>(runtime);
            calibration_id = next_id; session = next_session;
          }
          previous_stamp = stamp;
          auto image = cv::imdecode(jpeg, cv::IMREAD_COLOR);
          if (image.empty() || image.cols != calibration.at("width") || image.rows != calibration.at("height")) {
            pipeline.reset(); socket.send(result); continue;
          }
          const auto q = frame.at("q_gimbal2world").get<std::vector<double>>();
          if (q.size() != 4) throw std::runtime_error("Invalid attitude");
          pipeline->solver.set_R_gimbal2world(Eigen::Quaterniond(q[3],q[0],q[1],q[2]).normalized());
          const auto r = calibration.at("r_camera2gimbal").get<std::vector<double>>();
          const auto t = calibration.at("t_camera2gimbal").get<std::vector<double>>();
          if (r.size() != 9 || t.size() != 3) throw std::runtime_error("Invalid extrinsic calibration");
          pipeline->solver.set_camera2gimbal(
            Eigen::Map<const Eigen::Matrix<double,3,3,Eigen::RowMajor>>(r.data()),
            Eigen::Map<const Eigen::Vector3d>(t.data()));
          const auto begin = Steady::now();
          auto armors = yolo.detect(image, static_cast<int>(frame.at("seq").get<uint64_t>() % 1000000000));
          Json detected = Json::array();
          for (auto armor : armors) {
            pipeline->solver.solve(armor);
            Json points = Json::array();
            for (const auto & point : armor.points) points.push_back({point.x,point.y});
            detected.push_back({{"pose_valid",armor.pose_valid},{"corners",points},{"confidence",armor.confidence},
              {"color",auto_aim::COLORS.at(armor.color)},
              {"pose_constrained",armor.pose_constrained},{"reprojection_rms_px",armor.reprojection_rms_px},
              {"name",auto_aim::ARMOR_NAMES.at(armor.name)},
              {"type",auto_aim::ARMOR_TYPES.at(armor.type)}});
            if(armor.pose_valid && armor.xyz_in_world.allFinite())detected.back()["position"]={armor.xyz_in_world.x(),armor.xyz_in_world.y(),armor.xyz_in_world.z()};
          }
          auto targets = pipeline->tracker.track(armors, timestamp);
          Eigen::Vector3d muzzle_position = Eigen::Vector3d::Zero();
          if (aim_origin == "muzzle") {
            const auto m = frame.at("muzzle_position_map").get<std::vector<double>>();
            const auto g = frame.at("gimbal_position_map").get<std::vector<double>>();
            if (m.size()!=3 || g.size()!=3) throw std::runtime_error("Missing muzzle calibration");
            muzzle_position = Eigen::Vector3d(m[0]-g[0],m[1]-g[1],m[2]-g[2]);
          }
          pipeline->aimer.set_muzzle_position(muzzle_position);
          auto command = pipeline->aimer.aim(targets, timestamp, frame.at("bullet_speed").get<double>(), true);
          const auto & aim = pipeline->aimer.debug_aim_point;
          bool valid = command.control && aim.valid && std::isfinite(command.yaw) && std::isfinite(command.pitch);
          double distance = valid ? aim.xyza.head<3>().norm() : -1;
          result["valid"] = valid && distance > 0;
          result["yaw"] = valid ? command.yaw : 0;
          result["pitch"] = valid ? command.pitch : 0;
          result["distance"] = distance;
          result["aim_origin"] = aim_origin;
          result["muzzle_offset_world"] = {muzzle_position.x(),muzzle_position.y(),muzzle_position.z()};
          const Eigen::Vector3d ypr = tools::eulers(pipeline->solver.R_gimbal2world(), 2, 1, 0);
          result["fire_advice"] = !(profile=="tracking_fire_v2" || profile=="tracking_fire_v3") && pipeline->shooter.shoot(command, pipeline->aimer, targets, ypr) && result["valid"].get<bool>();
          result["algorithm_profile"]=profile;
          if(profile=="tracking_fire_v2" || profile=="tracking_fire_v3") {
            auto_aim::Shooter::FireContext context;
            context.capture_time=timestamp; context.now=Steady::now();
            context.tracking=pipeline->tracker.state()=="tracking";
            context.measurement_fresh=pipeline->tracker.diagnostics().value("trusted_update_age_s",1.)<=.05;
            context.generation=targets.empty()?0:targets.front().generation;
            context.plate_id=pipeline->aimer.selected_plate_id;
            if(profile=="tracking_fire_v3" && valid && !targets.empty()) {
              const Eigen::Vector3d impact=aim.xyza.head<3>()-muzzle_position;
              const double bearing=std::atan2(impact.y(),impact.x());
              const double width=targets.front().armor_type==auto_aim::big?.230:.135;
              const double facing=std::max(0.,std::cos(tools::limit_rad(aim.xyza[3]-bearing)));
              context.target_half_width_rad=std::atan2(width*.5*facing,impact.head<2>().norm());
            }
            if(frame.contains("latest_muzzle_pose")) {
              const auto &pose=frame["latest_muzzle_pose"];
              context.yaw=pose.at("yaw");context.elevation=pose.at("elevation");
              const int64_t wall=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
              context.pose_age_s=(wall-pose.at("stamp_ns").get<int64_t>())*1e-9;
            }
            result["fire_advice"]=pipeline->shooter.shoot_current(command,context)&&result["valid"].get<bool>();
          }
          result["detections"] = armors.size();
          result["tracking"] = !targets.empty();
          result["tracker"] = pipeline->tracker.state();
          // Read-only diagnostics for an independent evaluator. No simulator
          // target identity, state or visibility is supplied to this process.
          result["diagnostics_version"] = 1;
          result["observations"] = detected;
          if(profile=="tracking_v3" || profile=="tracking_fire_v3")result["detector_summary"]=yolo.summary();
          result["track_estimate"] = nullptr;
          result["aim_point"] = nullptr;
          if (!targets.empty()) {
            const auto & target = targets.front();
            auto state = target.ekf_x();
            Json plates = Json::array();
            for (const auto & plate : target.armor_xyza_list())
              plates.push_back({plate[0],plate[1],plate[2]});
            result["track_estimate"] = {
              {"frame","gimbal_origin_world_aligned"},
              {"name",auto_aim::ARMOR_NAMES.at(target.name)},
              {"center",{state[0],state[2],state[4]}},
              {"velocity",{state[1],state[3],state[5]}},
              {"yaw",state[6]},{"yaw_rate",state[7]},
              {"plates",plates}};
          }
          if (valid) result["aim_point"] = {aim.xyza[0],aim.xyza[1],aim.xyza[2]};
          attach_diagnostics(result,*pipeline,targets);
          result["pipeline_ms"] = std::chrono::duration<double,std::milli>(Steady::now()-begin).count();
          if (!socket.send(result)) break;
          ++processed;
          if (Steady::now() - last_report >= std::chrono::seconds(2)) {
            std::cout << Json{{"processed",processed},{"age_ms",age_ms},{"result",result}}.dump() << std::endl;
            last_report = Steady::now();
          }
          if (view) {
            for (const auto & armor : armors)
              for (const auto & p : armor.points) cv::circle(image, p, 3, {0,255,0}, -1);
            cv::putText(image, pipeline->tracker.state(), {20,40}, cv::FONT_HERSHEY_SIMPLEX, 1, {0,255,0}, 2);
            cv::imshow("Simulation auto aim", image);
            if (cv::waitKey(1) == 'q') stopping = 1;
          }
        }
      } catch (const std::exception & e) {
        std::cerr << "sim_auto_aim: " << e.what() << std::endl;
      }
      if (!stopping) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
  } catch (const std::exception & e) { std::cerr << e.what() << std::endl; return 1; }
  if (view) cv::destroyAllWindows();
  return 0;
}
