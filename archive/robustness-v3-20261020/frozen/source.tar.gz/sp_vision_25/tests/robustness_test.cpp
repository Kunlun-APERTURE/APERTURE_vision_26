#include <Eigen/Eigenvalues>
#include <chrono>
#include <iostream>
#include <stdexcept>
#include "tasks/auto_aim/plate_filter.hpp"
#include "tasks/auto_aim/shooter.hpp"
#include "tasks/auto_aim/tracker.hpp"
#include "tasks/auto_aim/detector.hpp"

static void require(bool value,const char *why) {if(!value)throw std::runtime_error(why);}
int main(int argc,char **argv) {
 try {
  require(argc==2,"config required");
  auto_aim::Detector detector(argv[1],false);
  for(auto color:{auto_aim::blue,auto_aim::red})for(int height:{6,14}) {
    cv::Mat image(720,1280,CV_8UC3,cv::Scalar(20,20,20));
    const cv::Scalar light=color==auto_aim::blue?cv::Scalar(100,20,20):cv::Scalar(20,20,100);
    cv::line(image,{590,340},{590,340+height},light,1);cv::line(image,{620,340},{620,340+height},light,1);
    cv::line(image,{605,340},{605,340+height},{255,255,255},1);
    auto_aim::Armor armor(9,.99,cv::Rect(590,340,30,height),{{590,340},{620,340},{620,float(340+height)},{590,float(340+height)}});armor.color=color;
    require(detector.detect(armor,image),"dim one-pixel colored bars were not refined");
    require(armor.points[0].x<595 && armor.points[1].x>615,"white number confused lightbar pairing");
    require(cv::norm(armor.center-(armor.points[0]+armor.points[1]+armor.points[2]+armor.points[3])*.25)<1e-5,"refined centre was stale");
  }
  {
    cv::Mat image(720,1280,CV_8UC3,cv::Scalar(20,20,20));cv::line(image,{590,340},{590,354},{20,255,20},2);cv::line(image,{620,340},{620,354},{20,255,20},2);
    auto_aim::Armor armor(9,.99,cv::Rect(590,340,30,14),{{590,340},{620,340},{620,354},{590,354}});
    const auto corners=armor.points;require(!detector.detect(armor,image),"green projectile color refined blue armour");require(armor.points==corners,"failed refinement changed corners");
  }
  for(int sign:{-1,1}) {
   auto_aim::PlateFilter filter;filter.bootstrap_enabled=true;
   Eigen::Matrix3d R=Eigen::Vector3d(.02,.0001,.0001).asDiagonal();
   for(int i=0;i<45;++i) {
    if(i)filter.predict(1./30,30,3,.1);
    const double t=i/30.;Eigen::Vector3d position(4+sign*.7*t,.4*t,0);
    require(filter.update(position,R,100),"radial observation rejected");
    Eigen::SelfAdjointEigenSolver<Eigen::Matrix<double,6,6>> solver(filter.P);
    require(solver.eigenvalues().minCoeff()>=-1e-10,"covariance not PSD");
   }
   require(std::abs(filter.velocity().x()-sign*.7)<.05,"approach/recede velocity biased");
   require(std::abs(filter.velocity().y()-.4)<.05,"diagonal velocity biased");
   require(filter.bootstrap_finished,"bootstrap never completed");
   const auto state=filter.x;
   require(!filter.update(Eigen::Vector3d(NAN,0,0),R,100),"nonfinite observation accepted");
   require(filter.x.isApprox(state,0),"invalid observation changed state");
  }
  auto_aim::PlateFilter gap;gap.bootstrap_enabled=true;gap.update({4,0,0},Eigen::Matrix3d::Identity()*.01,100);
  gap.predict(.15,30,3,.1);gap.update({4.1,0,0},Eigen::Matrix3d::Identity()*.01,100);
  require(gap.bootstrap_finished && gap.bootstrap_samples.empty(),"bootstrap crossed sample gap");
  auto_aim::Solver solver(argv[1]);auto_aim::Tracker tracker(argv[1],solver);
  for(double distance:{3.,8.})for(double yaw:{-.6,0.,.6}) {
    auto points=solver.reproject_armor({distance,0,0},yaw,auto_aim::small,auto_aim::three);
    auto_aim::Armor a(9,.99,cv::boundingRect(points),points);solver.solve(a);
    require(a.pose_constrained,"constrained pose test config was not enabled");
    require((a.xyz_in_world-Eigen::Vector3d(distance,0,0)).norm()<.1,"known projected geometry changed range");
  }
  {
    auto points=solver.reproject_armor({8,0,0},0,auto_aim::small,auto_aim::three);points[1].y-=2;
    auto_aim::Armor a(9,.99,cv::boundingRect(points),points);solver.solve(a,0.);
    require(a.pose_valid && (a.xyz_in_world-Eigen::Vector3d(8,0,0)).norm()<.5,"one noisy endpoint corrupted constrained range");
  }
  {
    auto points=solver.reproject_armor({4,0,0},.3,auto_aim::big,auto_aim::three);
    auto_aim::Armor a(29,.99,cv::boundingRect(points),points);solver.solve(a);
    require(!a.pose_constrained,"balance armour received an invalid fixed-pitch constraint");
  }
  const auto begin=std::chrono::steady_clock::time_point(std::chrono::seconds(50));
  for(int i=0;i<45;++i) {
    const auto points=solver.reproject_armor({3.8,0,0},0,auto_aim::small,auto_aim::three);
    std::list<auto_aim::Armor> detections={auto_aim::Armor(i<12?9:0,.99,cv::boundingRect(points),points)};
    const auto tracks=tracker.track(detections,begin+std::chrono::milliseconds(33*i));
    require(!tracks.empty(),"classifier flicker destroyed geometric track");
    require(tracks.front().name==auto_aim::three,"classifier flicker changed acquired robot identity");
    require(tracks.front().generation==1,"classifier flicker reset generation");
  }
  auto_aim::Shooter shooter(argv[1]);io::Command command{true,false,-CV_PI+.001,0};
  auto_aim::Shooter::FireContext c;c.yaw=CV_PI-.001;c.elevation=0;c.pose_age_s=.005;
  c.tracking=c.measurement_fresh=true;c.generation=1;c.plate_id=0;
  auto t=std::chrono::steady_clock::time_point(std::chrono::seconds(100));
  for(int i=0;i<10;++i) {c.capture_time=t+std::chrono::milliseconds(10*i);const bool yes=shooter.shoot_current(command,c);require(yes==(i>=4),"stable time incorrect");}
  c.plate_id=1;c.capture_time+=std::chrono::milliseconds(10);
  require(shooter.shoot_current(command,c),"continuous aim plate switch restarted gate");
  c.generation=2;c.capture_time+=std::chrono::milliseconds(10);
  require(!shooter.shoot_current(command,c),"new generation did not reset gate");
  for(int i=0;i<8;++i) {c.capture_time+=std::chrono::milliseconds(10);shooter.shoot_current(command,c);}
  c.pose_age_s=-.001;c.capture_time+=std::chrono::milliseconds(10);require(!shooter.shoot_current(command,c),"future pose allowed fire");
  c.pose_age_s=.06;c.capture_time+=std::chrono::milliseconds(10);require(!shooter.shoot_current(command,c),"stale pose allowed fire");
  c.pose_age_s=.005;c.elevation=.02;c.capture_time+=std::chrono::milliseconds(10);require(!shooter.shoot_current(command,c),"pitch error allowed fire");
  {
    bool fire=false;auto_aim::Shooter geometry(argv[1]);c={};c.yaw=0;c.elevation=0;c.pose_age_s=.005;c.tracking=c.measurement_fresh=true;c.generation=1;c.plate_id=0;
    c.target_half_width_rad=CV_PI/180.;command={true,false,.7*CV_PI/180.,0};
    for(int i=0;i<9;++i) {c.capture_time=t+std::chrono::milliseconds(10*i);fire=geometry.shoot_current(command,c);}
    require(fire,"geometry-bounded yaw window did not recover useful firing");
    c.capture_time+=std::chrono::milliseconds(33);c.measurement_fresh=c.tracking=false;
    require(!geometry.shoot_current(command,c),"missing observation allowed firing");
    require(geometry.diagnostics["qualification_held"].get<bool>(),"short miss unnecessarily discarded established qualification");
    c.capture_time+=std::chrono::milliseconds(33);c.measurement_fresh=c.tracking=true;
    require(geometry.shoot_current(command,c),"fresh continuous recovery repeated stabilization delay");
    c.capture_time+=std::chrono::milliseconds(10);c.target_half_width_rad=.3*CV_PI/180.;require(!geometry.shoot_current(command,c),"yaw window exceeded projected plate width");
    c.capture_time+=std::chrono::milliseconds(10);c.target_half_width_rad=0;require(!geometry.shoot_current(command,c),"back-facing prediction allowed fire");
  }
  {
    auto_aim::Shooter alignment(argv[1]);c={};c.yaw=.03;c.elevation=0;c.pose_age_s=.005;c.tracking=c.measurement_fresh=true;c.generation=1;c.plate_id=0;
    command={true,false,0,0};
    for(int i=0;i<10;++i) {c.capture_time=t+std::chrono::milliseconds(i*10);require(!alignment.shoot_current(command,c),"unaligned barrel fired during stability accumulation");}
    c.yaw=0;c.capture_time+=std::chrono::milliseconds(10);
    require(alignment.shoot_current(command,c),"newly aligned stable track repeated stabilization wait");
    c.pose_age_s=.1;c.capture_time+=std::chrono::milliseconds(10);require(!alignment.shoot_current(command,c),"pose expiry bypassed alignment gate");
    c.pose_age_s=.005;c.capture_time+=std::chrono::milliseconds(10);require(!alignment.shoot_current(command,c),"expired pose retained old stabilization credit");
    for(int i=0;i<9;++i) {c.capture_time+=std::chrono::milliseconds(10);alignment.shoot_current(command,c);}
    c.capture_time+=std::chrono::milliseconds(10);c.generation=2;require(!alignment.shoot_current(command,c),"alignment accumulation survived new generation");
  }
  std::cout<<"Color/subpixel lightbars, identity, geometric gate, bounded recovery; Radial/diagonal velocity, covariance, gap, gate duration, identity, yaw wrap and stale pose passed\n";
  return 0;
 } catch(const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
}
