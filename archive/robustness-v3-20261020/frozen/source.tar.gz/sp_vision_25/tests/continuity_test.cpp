#include <Eigen/Eigenvalues>
#include <chrono>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include "tasks/auto_aim/tracker.hpp"
#include "tasks/auto_aim/shooter.hpp"
#include "tools/math_tools.hpp"

static void check(bool value,const char *message) {
  if(!value)throw std::runtime_error(message);
}
using Clock=std::chrono::steady_clock;
static auto_aim::Armor observation(double y,double yaw=0) {
  auto_aim::Armor a(6,.99,cv::Rect(0,0,20,10),{{0,0},{20,0},{20,10},{0,10}});
  a.xyz_in_world={3.8,y,0};a.ypr_in_world={yaw,0,0};
  a.ypd_in_world=tools::xyz2ypd(a.xyz_in_world);
  a.pose_valid=true;a.reprojection_rms_px=.2;
  return a;
}

int main(int argc,char **argv) {
  try {
    check(argc==2,"test configuration required");
    auto config=auto_aim::ContinuityConfig::read(argv[1]);
    auto t=Clock::time_point(std::chrono::seconds(100));
    Eigen::VectorXd p=Eigen::VectorXd::Ones(11);
    auto armor=observation(0);
    auto_aim::Target target(armor,t,.2,4,p,config);
    const auto x=target.ekf_x();const auto P=target.ekf().P;
    auto bad=observation(5);
    check(!target.update_robust({{bad,0}}),"large outlier accepted");
    check(target.ekf_x().isApprox(x,0) && target.ekf().P.isApprox(P,0),"rejection changed filter state");
    double y=0;double crossing=-1;int accepted=0;
    for(int i=1;i<=180;++i) {
      const double v=i<=90?.5:-.5;
      y+=v/30;
      auto stamp=t+std::chrono::microseconds(i*33333);
      target.predict(stamp);
      auto a=observation(y+.001*std::sin(i*.7));
      accepted+=target.update_robust({{a,0}});
      check(target.ekf_x().allFinite() && target.ekf().P.allFinite(),"non-finite state");
      Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eigen(target.ekf().P);
      check(eigen.eigenvalues().minCoeff()>-1e-9,"covariance lost positive semidefiniteness");
      if(i>90 && crossing<0 && target.ekf_x()[3]<-.35)crossing=(i-90)/30.;
    }
    check(accepted>160,"valid motion repeatedly rejected");
    std::cout<<"target reversal recovery "<<crossing<<" s; accepted "<<accepted<<"/180\n";
    check(crossing>0 && crossing<=.3,"reversal velocity recovery exceeds 300 ms");
    check(std::abs(target.ekf_x()[3]+.5)<.15,"steady velocity inaccurate");
    auto_aim::Solver solver(argv[1]);
    auto projected=[&](double yy,int class_id=6) {
      auto points=solver.reproject_armor({3.8,yy,0},0,auto_aim::small,auto_aim::three);
      return auto_aim::Armor(class_id,.99,cv::boundingRect(points),points);
    };
    auto_aim::Tracker tracker(argv[1],solver);
    std::list<auto_aim::Target> tracks;
    for(int i=0;i<25;++i) {
      std::list<auto_aim::Armor> detections={projected(0,i==12?0:6)};
      if(i==15)detections.push_back(detections.front());
      if(i==17)detections.clear();
      tracks=tracker.track(detections,t+std::chrono::microseconds(i*33333));
      check(!tracks.empty(),"single missed/classification frame destroyed track");
      check(tracks.front().generation==1,"classification flicker/duplicate reset track");
    }
    check(tracker.state()=="tracking","tracking did not recover");
    for(int i=25;i<36;++i) {
      std::list<auto_aim::Armor> empty;
      tracker.track(empty,t+std::chrono::microseconds(i*33333));
    }
    check(tracker.state()=="lost","untrusted data kept trajectory alive");
    std::list<auto_aim::Armor> detections={projected(0)};
    tracker.track(detections,t+std::chrono::seconds(2));
    check(tracker.diagnostics()["generation"]==2,"reacquisition did not increment generation");
    tracker.track(detections,t+std::chrono::seconds(1));
    check(tracker.diagnostics()["reset_reason"]=="nonincreasing_timestamp","timestamp rollback not reported");

    auto_aim::Shooter shooter(argv[1]);
    io::Command command{true,false,-CV_PI+.001,0};
    auto_aim::Shooter::FireContext c;
    c.yaw=CV_PI-.001;c.elevation=0;c.pose_age_s=.005;
    c.tracking=c.measurement_fresh=true;c.generation=1;c.plate_id=0;
    bool fire=false;
    for(int i=0;i<8;++i) {
      c.capture_time=t+std::chrono::microseconds(i*33333);fire=shooter.shoot_current(command,c);
    }
    check(fire,"wrapped yaw prevented aligned firing");
    c.capture_time+=std::chrono::milliseconds(33);c.elevation=.04;
    check(!shooter.shoot_current(command,c),"pitch misalignment permitted firing");
    c.capture_time+=std::chrono::milliseconds(33);c.elevation=0;c.pose_age_s=.06;
    check(!shooter.shoot_current(command,c),"stale own pose permitted firing");
    c.capture_time+=std::chrono::milliseconds(33);c.pose_age_s=.005;c.measurement_fresh=false;
    check(!shooter.shoot_current(command,c),"untrusted tracking permitted firing");
    std::cout<<"classification, duplicates, dropout, timestamps, yaw wrap, pitch and pose freshness passed\n";
    return 0;
  } catch(const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
}
